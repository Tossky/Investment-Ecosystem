export type Currency = 'NGN' | 'USD';

export type RiskProfile = 'Conservative' | 'Balanced' | 'Growth' | 'High-Yield Private';

export type AssetCategory = 'Real Estate' | 'Private Business Debt' | 'Money Market' | 'Tech Venture' | 'Infrastructure' | 'Fractional Vault';

export type KycTier = 'Tier 1 (Basic)' | 'Tier 2 (Verified ID)' | 'Tier 3 (Accredited)';

export interface Opportunity {
  id: string;
  title: string;
  subtitle: string;
  category: AssetCategory;
  sponsorName: string;
  sponsorBadge: string;
  riskRating: 'AAA' | 'AA' | 'A' | 'B+' | 'B';
  expectedReturnPcnt: number; // e.g., 18.5 for 18.5% p.a.
  tenureMonths: number;
  minInvestmentNgn: number;
  minInvestmentUsd: number;
  targetCapitalNgn: number;
  raisedCapitalNgn: number;
  coInvestorsCount: number;
  isFractionalPool: boolean;
  payoutFrequency: 'Monthly' | 'Quarterly' | 'Bi-Annually' | 'At Maturity';
  assetLocation?: string;
  secRegNumber: string;
  collateralDescription: string;
  dueDiligenceScore: number; // 0 - 100
  summary: string;
  highlights: string[];
  auditedFinancialsUrl?: string;
  offeringDocumentUrl?: string;
  image: string;
}

export interface PortfolioAllocation {
  category: AssetCategory;
  percentage: number;
  recommendedNgn: number;
  recommendedUsd: number;
  expectedYieldPcnt: number;
  rationale: string;
}

export interface UserInvestment {
  id: string;
  opportunityId: string;
  opportunityTitle: string;
  category: AssetCategory;
  amountNgn: number;
  amountUsd: number;
  investedDate: string;
  maturityDate: string;
  expectedPayoutNgn: number;
  expectedPayoutUsd: number;
  yieldEarnedToDateNgn: number;
  status: 'Active' | 'Matured' | 'Payout In Progress';
  nextPayoutDate: string;
}

export interface CapitalRaiseApplication {
  id: string;
  companyName: string;
  industry: string;
  fundingType: 'Commercial Debt' | 'Equity Share' | 'Revenue Share' | 'Real Estate Syndication';
  targetAmountNgn: number;
  offeredYieldPcnt: number;
  tenureMonths: number;
  useOfFunds: string;
  collateralProvided: string;
  arrNgn: number;
  grossMarginPcnt: number;
  status: 'Under Review' | 'Vetted & Approved' | 'Live in Marketplace' | 'Fully Funded';
  vettingScore: number;
}

export interface AdvisoryConsultant {
  id: string;
  name: string;
  title: string;
  credentials: string;
  experienceYears: number;
  specialization: string;
  rating: number;
  reviewsCount: number;
  avatar: string;
  availableDays: string[];
  hourlyRateNgn: number;
  hourlyRateUsd: number;
}

export interface LearningArticle {
  id: string;
  title: string;
  category: 'Wealth Strategy' | 'SME Raising' | 'Regulatory & SEC' | 'Fractional Ownership';
  readTimeMinutes: number;
  author: string;
  publishedDate: string;
  summary: string;
  content: string;
  featuredImage: string;
  isMasterclassVideo?: boolean;
}

export interface SchemaTable {
  name: string;
  description: string;
  columns: { name: string; type: string; constraints: string; description: string }[];
}

export interface SystemPipeline {
  id: string;
  title: string;
  category: 'Capital Matching' | 'Vetting & Risk' | 'Settlement & Vault' | 'KYC & Compliance';
  steps: { stepNumber: number; title: string; actor: string; systemAction: string }[];
}
