import { Currency } from '../types';

export const NGN_TO_USD_RATE = 1550; // Demo exchange rate ₦1550 = $1

export function formatCurrency(amountNgn: number, currency: Currency): string {
  if (currency === 'USD') {
    const amountUsd = amountNgn / NGN_TO_USD_RATE;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(amountUsd);
  }

  return new Intl.NumberFormat('en-NG', {
    style: 'currency',
    currency: 'NGN',
    maximumFractionDigits: 0,
  }).format(amountNgn).replace('NGN', '₦');
}

export function formatNumber(num: number): string {
  return new Intl.NumberFormat('en-US').format(num);
}

export function formatPercent(num: number): string {
  return `${num.toFixed(1)}%`;
}

export function calculateCompoundGrowth(
  principalNgn: number,
  annualRatePcnt: number,
  years: number
): { year: number; balanceNgn: number; yieldEarnedNgn: number }[] {
  const result = [];
  let current = principalNgn;
  const rate = annualRatePcnt / 100;

  for (let y = 0; y <= years; y++) {
    if (y === 0) {
      result.push({ year: 0, balanceNgn: current, yieldEarnedNgn: 0 });
    } else {
      const yieldThisYear = current * rate;
      current += yieldThisYear;
      result.push({
        year: y,
        balanceNgn: Math.round(current),
        yieldEarnedNgn: Math.round(current - principalNgn),
      });
    }
  }

  return result;
}
