import React, { useState } from 'react';
import { Currency, RiskProfile, PortfolioAllocation } from '../types';
import { formatCurrency, calculateCompoundGrowth } from '../utils/formatters';
import {
  Sliders,
  TrendingUp,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  PieChart as PieChartIcon,
  Zap,
  CheckCircle2,
  Building,
  Briefcase,
  DollarSign,
  Info,
  Layers,
  Compass,
  Target,
  UserCheck,
  BookOpen,
  Calendar,
  AlertCircle,
  HelpCircle,
  BarChart3,
  ChevronRight,
  Award,
  RefreshCw,
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
} from 'recharts';
import confetti from 'canvas-confetti';

interface MatchmakingEngineProps {
  currency: Currency;
  onDeployAllocation: (allocations: PortfolioAllocation[]) => void;
  onSelectMarketplaceItem: (id: string) => void;
  onSwitchToSeeker?: () => void;
  onBookConsultation?: (topic: string) => void;
  onOpenAcademy?: () => void;
}

export const MatchmakingEngine: React.FC<MatchmakingEngineProps> = ({
  currency,
  onDeployAllocation,
  onSelectMarketplaceItem,
  onSwitchToSeeker,
  onBookConsultation,
  onOpenAcademy,
}) => {
  // Mode State: 'front-door' | 'assessment-flow' | 'report' | 'allocator'
  const [activeMode, setActiveMode] = useState<'front-door' | 'assessment-flow' | 'report' | 'allocator'>('front-door');

  // Assessment Form State (Conversational Sections A to I)
  const [assessmentStep, setAssessmentStep] = useState<number>(0);
  const [answers, setAnswers] = useState({
    // Section A: Personal Profile
    ageRange: '25-34',
    country: 'Nigeria',
    employmentStatus: 'Employed Full-time',
    industry: 'Technology & Services',
    dependants: 2,
    mainGoal: 'Build Long-Term Wealth',

    // Section B: Income
    monthlyIncomeNgn: 750000,
    incomeType: 'Fixed Monthly Salary',
    primaryIncomeSource: 'Corporate Job',
    additionalIncome: 'Freelance / Side Gig',
    passiveIncomeNgn: 30000,
    expectedGrowth: 'Moderate (10-25% annually)',

    // Section C: Expenses & Debt
    monthlyExpensesNgn: 420000,
    debtObligationNgn: 50000,
    monthlySurplusNgn: 280000,

    // Section D: Savings
    currentSavingsNgn: 1500000,
    emergencyReserveMonths: 3.5,
    savingFrequency: 'Regularly every month',
    monthlyCommitmentNgn: 200000,

    // Section E: Investment Experience
    investedBefore: 'Yes, basic fixed deposits & stocks',
    knowledgeLevel: 'Intermediate',
    riskUnderstanding: 'Understands risk vs return tradeoffs',

    // Section F: Goals & Timeline
    timeHorizonYears: 3,
    objectiveType: 'Balanced Income & Capital Growth',

    // Section G: Risk & Liquidity
    lossReaction: 'Stay calm and wait for recovery',
    liquidityAccess: 'Medium (Quarterly access fine)',

    // Section H: Personal Development
    incomeVsCapital: 'Increasing income would provide faster growth than current capital',
    skillBlocking: 'Need certified financial & management skills',

    // Section I: Business Ownership
    ownsBusiness: 'No',
    businessName: '',
    businessRevenueNgn: 0,
    businessFundingNeededNgn: 0,
  });

  // Generated Readiness Scores State
  const [readinessReport, setReadinessReport] = useState<{
    financialStability: number;
    cashflowStrength: number;
    investmentKnowledge: number;
    liquidityPosition: number;
    riskCapacity: number;
    goalClarity: number;
    overallReadiness: number;
    primaryRoute: 'ROUTE_01' | 'ROUTE_02' | 'ROUTE_03' | 'ROUTE_04' | 'ROUTE_05';
    routeTitle: string;
    routeSubtitle: string;
    strengths: string[];
    gaps: string[];
    nextAction: string;
  }>({
    financialStability: 74,
    cashflowStrength: 68,
    investmentKnowledge: 62,
    liquidityPosition: 70,
    riskCapacity: 58,
    goalClarity: 85,
    overallReadiness: 70,
    primaryRoute: 'ROUTE_01',
    routeTitle: 'Route 01 — Investment Ready',
    routeSubtitle: 'You maintain healthy surplus cash flow and emergency liquidity to safely deploy into vetted opportunities.',
    strengths: [
      'Positive monthly cash surplus (₦280,000/mo)',
      '3.5 months emergency liquid reserve established',
      'Clear 3-year timeline with balanced risk expectation',
    ],
    gaps: [
      'Can boost yield diversification by splitting between T-Bills and Senior Corporate Debt Notes',
      'Knowledge of private credit due-diligence scoring can be deepened',
    ],
    nextAction: 'Explore Vetted Investment Opportunities or execute the Algorithmic Matchmaker Allocation.',
  });

  // Allocator Wizard Input States
  const [investmentNgn, setInvestmentNgn] = useState<number>(250000);
  const [primaryGoal, setPrimaryGoal] = useState<'preservation' | 'yield' | 'growth' | 'ultra'>('yield');
  const [riskTolerance, setRiskTolerance] = useState<RiskProfile>('Balanced');
  const [timelineYears, setTimelineYears] = useState<number>(3);
  const [liquidityNeed, setLiquidityNeed] = useState<'high' | 'medium' | 'low'>('medium');

  const presetAmountsNgn = [2000, 50000, 250000, 1000000, 5000000, 25000000];

  // Dynamic Portfolio Allocation Engine
  const calculateAllocations = (): PortfolioAllocation[] => {
    let re = 30;
    let debt = 35;
    let mm = 25;
    let vault = 10;

    if (riskTolerance === 'Conservative') {
      mm = 55; re = 25; debt = 15; vault = 5;
    } else if (riskTolerance === 'Balanced') {
      mm = 25; re = 35; debt = 30; vault = 10;
    } else if (riskTolerance === 'Growth') {
      mm = 10; re = 35; debt = 40; vault = 15;
    } else if (riskTolerance === 'High-Yield Private') {
      mm = 5; re = 30; debt = 45; vault = 20;
    }

    if (liquidityNeed === 'high') {
      mm += 20;
      debt = Math.max(10, debt - 10);
      re = Math.max(10, re - 10);
    }

    return [
      {
        category: 'Money Market',
        percentage: mm,
        recommendedNgn: Math.round((investmentNgn * mm) / 100),
        recommendedUsd: Math.round(((investmentNgn * mm) / 100) / 1550),
        expectedYieldPcnt: 15.2,
        rationale: 'Instant 24-hr liquidity backed 100% by Sovereign Treasury T-Bills.',
      },
      {
        category: 'Real Estate',
        percentage: re,
        recommendedNgn: Math.round((investmentNgn * re) / 100),
        recommendedUsd: Math.round(((investmentNgn * re) / 100) / 1550),
        expectedYieldPcnt: 18.5,
        rationale: 'Prime commercial property vault equity providing quarterly rental dividends.',
      },
      {
        category: 'Private Business Debt',
        percentage: debt,
        recommendedNgn: Math.round((investmentNgn * debt) / 100),
        recommendedUsd: Math.round(((investmentNgn * debt) / 100) / 1550),
        expectedYieldPcnt: 22.0,
        rationale: 'Secured corporate debt notes backed by equipment/receivables.',
      },
      {
        category: 'Fractional Vault',
        percentage: vault,
        recommendedNgn: Math.round((investmentNgn * vault) / 100),
        recommendedUsd: Math.round(((investmentNgn * vault) / 100) / 1550),
        expectedYieldPcnt: 28.0,
        rationale: 'Co-investment micro-pool for scalable growth assets from ₦2,000.',
      },
    ];
  };

  const allocations = calculateAllocations();
  const weightedYieldPcnt = allocations.reduce((acc, curr) => acc + (curr.expectedYieldPcnt * curr.percentage) / 100, 0);
  const growthProjection = calculateCompoundGrowth(investmentNgn, weightedYieldPcnt, timelineYears);
  const projectedEndBalanceNgn = growthProjection[growthProjection.length - 1].balanceNgn;
  const projectedTotalYieldNgn = projectedEndBalanceNgn - investmentNgn;

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6'];

  // Handle Assessment Completion & Route Computation
  const handleCompleteAssessment = () => {
    // Calculate readiness metric heuristics
    const surplusRatio = (answers.monthlySurplusNgn / (answers.monthlyIncomeNgn || 1)) * 100;
    const reserveMonths = answers.emergencyReserveMonths;
    const ownsBiz = answers.ownsBusiness === 'Yes';

    let stability = Math.min(100, Math.round(reserveMonths * 22));
    let cashflow = Math.min(100, Math.round(surplusRatio * 2.2));
    let knowledge = answers.knowledgeLevel === 'Advanced' ? 90 : answers.knowledgeLevel === 'Intermediate' ? 65 : 40;
    let liquidity = reserveMonths >= 3 ? 80 : 45;
    let riskCap = answers.timeHorizonYears >= 3 ? 75 : 50;
    let goalClr = 85;

    let overall = Math.round((stability + cashflow + knowledge + liquidity + riskCap + goalClr) / 6);

    let route: 'ROUTE_01' | 'ROUTE_02' | 'ROUTE_03' | 'ROUTE_04' | 'ROUTE_05' = 'ROUTE_01';
    let rTitle = 'Route 01 — Investment Ready';
    let rSubtitle = 'You possess stable financial cushions and recurring surplus to deploy into vetted opportunities.';
    let str: string[] = [];
    let gp: string[] = [];
    let action = '';

    if (ownsBiz && answers.businessFundingNeededNgn > 0) {
      route = 'ROUTE_04';
      rTitle = 'Route 04 — Business Growth & Capital Raising';
      rSubtitle = 'Your primary leverage point is scaling your operational business and securing capital funding.';
      str = ['Active business operation with established customer revenue', 'Clear capital deployment objective'];
      gp = ['Requires formal 8-point due-diligence review and audited statements'];
      action = 'Apply for SME Capital Raising in the Business Funding Portal.';
    } else if (surplusRatio < 15 || reserveMonths < 2) {
      route = 'ROUTE_02';
      rTitle = 'Route 02 — Build Cash Flow First';
      rSubtitle = 'Not everyone who has money needs an investment immediately. Your smartest next step is building income and emergency liquidity.';
      str = ['Desire to build financial discipline and long-term security'];
      gp = ['Low emergency cushion (under 2 months of expenses)', 'Limited monthly surplus cash flow'];
      action = 'Follow the Cash Flow Growth Plan: Income Optimization -> Savings Discipline -> Financial Foundation.';
    } else if (answers.incomeVsCapital.includes('Increasing income') || answers.knowledgeLevel === 'Beginner') {
      route = 'ROUTE_03';
      rTitle = 'Route 03 — Invest In Yourself (Skills & Education)';
      rSubtitle = 'Your highest return on investment right now is increasing your personal earning capability and financial literacy.';
      str = ['High growth potential through skill acquisition and career advancement'];
      gp = ['Earning capacity cap due to missing certifications or domain knowledge'];
      action = 'Enroll in Bammy Investment School masterclasses or book a Career & Skill Advisor.';
    } else if (overall >= 65) {
      route = 'ROUTE_01';
      rTitle = 'Route 01 — Investment Ready';
      rSubtitle = 'You meet liquidity and cash-flow thresholds for regulated & vetted opportunity participation.';
      str = ['Healthy emergency reserve (>3 months expenses)', 'Steady monthly cash surplus', 'Clear investment timeline'];
      gp = ['Optimize portfolio yield by balancing liquid money market with corporate debt notes'];
      action = 'Review Vetted Opportunities or execute the Algorithmic Asset Matchmaker.';
    } else {
      route = 'ROUTE_05';
      rTitle = 'Route 05 — Personal Consultation Required';
      rSubtitle = 'Your financial profile requires nuanced 1-on-1 human advisory to design a tailored roadmap.';
      str = ['Clear ambition to transform personal financial trajectory'];
      gp = ['Complex financial trade-offs requiring expert structuring'];
      action = 'Book a 1-on-1 session with a Certified Capital Growth Advisor.';
    }

    setReadinessReport({
      financialStability: stability,
      cashflowStrength: cashflow,
      investmentKnowledge: knowledge,
      liquidityPosition: liquidity,
      riskCapacity: riskCap,
      goalClarity: goalClr,
      overallReadiness: overall,
      primaryRoute: route,
      routeTitle: rTitle,
      routeSubtitle: rSubtitle,
      strengths: str,
      gaps: gp,
      nextAction: action,
    });

    setActiveMode('report');
  };

  const handleDeploy = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });
    onDeployAllocation(allocations);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Mode Switcher Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-3 bg-slate-900 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveMode('front-door')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeMode === 'front-door'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>AI Discovery & Assessment</span>
          </button>
          {activeMode === 'report' && (
            <button
              onClick={() => setActiveMode('report')}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 text-white shadow-md flex items-center gap-2"
            >
              <Award className="w-4 h-4" />
              <span>Financial Readiness Report</span>
            </button>
          )}
          <button
            onClick={() => setActiveMode('allocator')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeMode === 'allocator'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>Algorithmic Yield Matchmaker</span>
          </button>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400 font-semibold">
          <ShieldCheck className="w-4 h-4 text-blue-400" />
          <span className="hidden sm:inline">Bammy AI Strategy Engine • SEC Disclosed Advisory</span>
        </div>
      </div>

      {/* VIEW MODE 1: FRONT DOOR HERO & DISCOVERY */}
      {activeMode === 'front-door' && (
        <div className="space-y-10">
          {/* Hero Section */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-8 sm:p-12 border border-slate-800 shadow-2xl space-y-8">
            <div className="absolute top-0 right-0 -mt-20 -mr-20 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
            
            <div className="max-w-3xl space-y-4">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" /> AI-First Financial Growth Ecosystem
              </div>
              <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight">
                Your Money Needs a Strategy. <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-emerald-400">
                  Not Just an Investment.
                </span>
              </h1>
              <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
                Understand where you are financially, discover your smartest growth pathway, and access carefully evaluated opportunities designed around your goals.
              </p>
            </div>

            {/* Action CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 pt-2">
              <button
                onClick={() => {
                  setAssessmentStep(1);
                  setActiveMode('assessment-flow');
                }}
                className="px-8 py-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-base shadow-xl shadow-blue-950 flex items-center justify-center gap-3 transition hover:scale-105"
              >
                <span>Assess My Financial Position</span>
                <ArrowRight className="w-5 h-5" />
              </button>
              <button
                onClick={onSwitchToSeeker}
                className="px-8 py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-200 font-extrabold text-base border border-slate-700 flex items-center justify-center gap-3 transition"
              >
                <Building className="w-5 h-5 text-blue-400" />
                <span>Explore Business Capital & Funding</span>
              </button>
            </div>

            {/* Core Principle Banner */}
            <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 space-y-2">
              <div className="text-xs font-bold text-blue-400 uppercase tracking-wider flex items-center gap-2">
                <Info className="w-4 h-4 text-blue-400" /> The Bammy Growth Principle
              </div>
              <p className="text-slate-200 text-sm italic font-medium leading-relaxed">
                «Not everyone who has money needs an investment immediately. Sometimes the best investment is first creating the ability to generate more money.»
              </p>
            </div>
          </div>

          {/* Section 2: Before You Invest */}
          <div className="space-y-6">
            <div className="text-center max-w-2xl mx-auto space-y-2">
              <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">
                Step-by-Step Intelligence
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                Before You Invest, Understand What You Actually Need
              </h2>
              <p className="text-slate-400 text-xs sm:text-sm">
                Our AI assessment evaluates your complete financial picture to route you into the right growth pathway.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {[
                {
                  route: '01',
                  title: 'Investment Ready',
                  desc: 'Regulated money market, real estate & private credit deals.',
                  color: 'border-blue-500/40 bg-blue-950/20 text-blue-400',
                  icon: TrendingUp,
                },
                {
                  route: '02',
                  title: 'Build Cash Flow',
                  desc: 'Income optimization & emergency savings foundation.',
                  color: 'border-indigo-500/40 bg-indigo-950/20 text-indigo-400',
                  icon: DollarSign,
                },
                {
                  route: '03',
                  title: 'Invest in Yourself',
                  desc: 'Professional certifications, skills & career transition.',
                  color: 'border-emerald-500/40 bg-emerald-950/20 text-emerald-400',
                  icon: BookOpen,
                },
                {
                  route: '04',
                  title: 'Business Growth',
                  desc: 'Capital raising, strategy, tech & 8-point due diligence.',
                  color: 'border-amber-500/40 bg-amber-950/20 text-amber-400',
                  icon: Building,
                },
                {
                  route: '05',
                  title: 'Consultation',
                  desc: '1-on-1 expert human advisory session with pre-summary.',
                  color: 'border-purple-500/40 bg-purple-950/20 text-purple-400',
                  icon: Calendar,
                },
              ].map((card) => {
                const Icon = card.icon;
                return (
                  <div
                    key={card.route}
                    className={`p-5 rounded-2xl border ${card.color} space-y-3 flex flex-col justify-between shadow-lg`}
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-slate-900 border border-slate-700">
                          Route {card.route}
                        </span>
                        <Icon className="w-5 h-5" />
                      </div>
                      <h3 className="font-bold text-white text-base">{card.title}</h3>
                      <p className="text-xs text-slate-400 leading-relaxed">{card.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section 3: The 6-Step Journey */}
          <div className="p-8 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6">
            <h3 className="text-xl font-extrabold text-white text-center">
              From Financial Assessment to Wealth Creation
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 text-center">
              {[
                { step: '1', title: 'Tell Us About Yourself', desc: 'Conversational profile' },
                { step: '2', title: 'Understand Your Position', desc: 'Readiness scores' },
                { step: '3', title: 'Identify Your Pathway', desc: 'Route 01 to 05' },
                { step: '4', title: 'Get Guidance', desc: 'AI + Human Advisor' },
                { step: '5', title: 'Discover Opportunities', desc: 'Vetted partner products' },
                { step: '6', title: 'Track Progress', desc: 'Monitoring dashboard' },
              ].map((s) => (
                <div key={s.step} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <div className="w-7 h-7 rounded-full bg-blue-600 text-white font-extrabold text-xs mx-auto flex items-center justify-center">
                    {s.step}
                  </div>
                  <p className="font-bold text-white text-xs mt-2">{s.title}</p>
                  <p className="text-[10px] text-slate-400">{s.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* VIEW MODE 2: CONVERSATIONAL AI ASSESSMENT QUESTIONNAIRE */}
      {activeMode === 'assessment-flow' && (
        <div className="max-w-3xl mx-auto bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-2xl space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">
                AI Financial Discovery
              </span>
              <h2 className="text-xl font-extrabold text-white">
                Conversational Readiness Assessment
              </h2>
            </div>
            <div className="text-right">
              <span className="text-xs font-bold text-slate-400">Step {assessmentStep} of 4</span>
              <div className="w-24 bg-slate-800 h-2 rounded-full overflow-hidden mt-1">
                <div
                  className="bg-blue-600 h-full transition-all duration-300"
                  style={{ width: `${(assessmentStep / 4) * 100}%` }}
                />
              </div>
            </div>
          </div>

          {/* STEP 1: Personal Profile & Income */}
          {assessmentStep === 1 && (
            <div className="space-y-5 animate-fadeIn">
              <h3 className="text-base font-bold text-blue-400 flex items-center gap-2">
                <UserCheck className="w-5 h-5" /> Section A & B: Personal Profile & Income
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Age Range</label>
                  <select
                    value={answers.ageRange}
                    onChange={(e) => setAnswers({ ...answers, ageRange: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  >
                    <option value="18-24">18 - 24 years</option>
                    <option value="25-34">25 - 34 years</option>
                    <option value="35-44">35 - 44 years</option>
                    <option value="45-54">45 - 54 years</option>
                    <option value="55+">55+ years</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Employment Status</label>
                  <select
                    value={answers.employmentStatus}
                    onChange={(e) => setAnswers({ ...answers, employmentStatus: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  >
                    <option value="Employed Full-time">Employed Full-time</option>
                    <option value="Business Owner / Founder">Business Owner / Founder</option>
                    <option value="Freelancer / Consultant">Freelancer / Consultant</option>
                    <option value="Self-Employed">Self-Employed</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Average Monthly Income (₦)</label>
                  <input
                    type="number"
                    value={answers.monthlyIncomeNgn}
                    onChange={(e) => setAnswers({ ...answers, monthlyIncomeNgn: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Income Type</label>
                  <select
                    value={answers.incomeType}
                    onChange={(e) => setAnswers({ ...answers, incomeType: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  >
                    <option value="Fixed Monthly Salary">Fixed Monthly Salary</option>
                    <option value="Variable Business Revenue">Variable Business Revenue</option>
                    <option value="Commission / Performance Based">Commission / Performance Based</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <button
                  onClick={() => setAssessmentStep(2)}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2"
                >
                  <span>Continue to Expenses & Savings</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Expenses, Savings & Debt */}
          {assessmentStep === 2 && (
            <div className="space-y-5 animate-fadeIn">
              <h3 className="text-base font-bold text-blue-400 flex items-center gap-2">
                <DollarSign className="w-5 h-5" /> Section C & D: Expenses, Debt & Reserve
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Average Monthly Expenses (₦)</label>
                  <input
                    type="number"
                    value={answers.monthlyExpensesNgn}
                    onChange={(e) => {
                      const exp = Number(e.target.value);
                      const surplus = Math.max(0, answers.monthlyIncomeNgn - exp - answers.debtObligationNgn);
                      setAnswers({ ...answers, monthlyExpensesNgn: exp, monthlySurplusNgn: surplus });
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Current Emergency Liquid Reserve (Months)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={answers.emergencyReserveMonths}
                    onChange={(e) => setAnswers({ ...answers, emergencyReserveMonths: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Monthly Surplus Cash Flow (₦)</label>
                  <input
                    type="number"
                    value={answers.monthlySurplusNgn}
                    readOnly
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-blue-400 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Total Liquid Savings Available (₦)</label>
                  <input
                    type="number"
                    value={answers.currentSavingsNgn}
                    onChange={(e) => setAnswers({ ...answers, currentSavingsNgn: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  />
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <button
                  onClick={() => setAssessmentStep(1)}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs"
                >
                  Back
                </button>
                <button
                  onClick={() => setAssessmentStep(3)}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2"
                >
                  <span>Continue to Experience & Goals</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Experience, Goals & Personal Development */}
          {assessmentStep === 3 && (
            <div className="space-y-5 animate-fadeIn">
              <h3 className="text-base font-bold text-blue-400 flex items-center gap-2">
                <Target className="w-5 h-5" /> Section E, F & H: Experience & Personal Development
              </h3>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Investment Knowledge Level</label>
                  <select
                    value={answers.knowledgeLevel}
                    onChange={(e) => setAnswers({ ...answers, knowledgeLevel: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  >
                    <option value="Beginner">Beginner (Learning fundamentals)</option>
                    <option value="Intermediate">Intermediate (Have invested in T-Bills, Stocks)</option>
                    <option value="Advanced">Advanced (Experienced in private debt, real estate)</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Personal Earning Lever</label>
                  <select
                    value={answers.incomeVsCapital}
                    onChange={(e) => setAnswers({ ...answers, incomeVsCapital: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  >
                    <option value="Increasing income would provide faster growth than current capital">
                      Increasing income via skill/business would yield higher growth than current capital
                    </option>
                    <option value="My primary income is optimized; I need capital yield deployment">
                      Primary income is optimized; focus on capital yield deployment
                    </option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Do you own an operational business?</label>
                  <select
                    value={answers.ownsBusiness}
                    onChange={(e) => setAnswers({ ...answers, ownsBusiness: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                  >
                    <option value="No">No, I am an individual investor / employee</option>
                    <option value="Yes">Yes, I own/run a registered business seeking growth</option>
                  </select>
                </div>

                {answers.ownsBusiness === 'Yes' && (
                  <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Business Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Acme Tech Solutions Ltd"
                        value={answers.businessName}
                        onChange={(e) => setAnswers({ ...answers, businessName: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-semibold text-slate-300 block mb-1">Funding Required (₦)</label>
                      <input
                        type="number"
                        value={answers.businessFundingNeededNgn}
                        onChange={(e) => setAnswers({ ...answers, businessFundingNeededNgn: Number(e.target.value) })}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-white"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-between pt-4">
                <button
                  onClick={() => setAssessmentStep(2)}
                  className="px-5 py-2.5 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs"
                >
                  Back
                </button>
                <button
                  onClick={handleCompleteAssessment}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-500 hover:to-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>Generate AI Financial Growth Report</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* VIEW MODE 3: FINANCIAL GROWTH REPORT (PAGE 3 & ROUTE RECOMMENDATION) */}
      {activeMode === 'report' && (
        <div className="space-y-8 animate-fadeIn">
          {/* Report Top Banner */}
          <div className="p-6 sm:p-8 bg-slate-900/90 rounded-3xl border border-slate-800 shadow-xl space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
              <div>
                <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">
                  System 02 & 03 — Decision Support Report
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
                  Your Financial Readiness Scorecard
                </h2>
                <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
                  Internal AI decision-support profile. (Not a guaranteed financial promise).
                </p>
              </div>

              <div className="flex items-center gap-4 bg-slate-950 p-4 rounded-2xl border border-slate-800 shrink-0">
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Overall Readiness Score</span>
                  <span className="text-3xl font-black text-blue-400 font-mono">
                    {readinessReport.overallReadiness}<span className="text-slate-500 text-lg">/100</span>
                  </span>
                </div>
                <div className="w-12 h-12 rounded-2xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 font-bold">
                  <Award className="w-6 h-6" />
                </div>
              </div>
            </div>

            {/* 6 Sub-Scores Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {[
                { label: 'Financial Stability', score: readinessReport.financialStability },
                { label: 'Cash-Flow Strength', score: readinessReport.cashflowStrength },
                { label: 'Investment Knowledge', score: readinessReport.investmentKnowledge },
                { label: 'Liquidity Position', score: readinessReport.liquidityPosition },
                { label: 'Risk Capacity', score: readinessReport.riskCapacity },
                { label: 'Goal Clarity', score: readinessReport.goalClarity },
              ].map((m) => (
                <div key={m.label} className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-[10px] text-slate-400 font-bold block">{m.label}</span>
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-white text-base font-mono">{m.score}/100</span>
                    <div className="w-10 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-blue-500 h-full" style={{ width: `${m.score}%` }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recommended Growth Pathway Route */}
          <div className="p-6 sm:p-8 bg-gradient-to-br from-blue-950/60 via-slate-900 to-slate-950 rounded-3xl border border-blue-800/80 shadow-2xl space-y-6">
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 rounded-full bg-blue-600 text-white font-extrabold text-xs uppercase tracking-wider">
                Recommended Primary Pathway
              </span>
              <span className="text-xs text-blue-300 font-semibold">Matched by AI Intelligence</span>
            </div>

            <div className="space-y-2">
              <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
                {readinessReport.routeTitle}
              </h3>
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                {readinessReport.routeSubtitle}
              </p>
            </div>

            {/* Strengths & Gaps */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-2">
                <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" /> Verified Financial Strengths
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {readinessReport.strengths.map((s, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-emerald-400 font-bold">•</span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-2">
                <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-2">
                  <AlertCircle className="w-4 h-4" /> Identified Growth Gaps & Levers
                </h4>
                <ul className="space-y-1.5 text-xs text-slate-300">
                  {readinessReport.gaps.map((g, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <span className="text-amber-400 font-bold">•</span>
                      <span>{g}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Next Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-slate-800">
              {readinessReport.primaryRoute === 'ROUTE_01' && (
                <button
                  onClick={() => setActiveMode('allocator')}
                  className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg flex items-center justify-center gap-2"
                >
                  <Sliders className="w-4 h-4" />
                  <span>Execute Algorithmic Yield Allocator</span>
                </button>
              )}

              {readinessReport.primaryRoute === 'ROUTE_04' && (
                <button
                  onClick={onSwitchToSeeker}
                  className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg flex items-center justify-center gap-2"
                >
                  <Building className="w-4 h-4" />
                  <span>Apply for Capital Raising Portal</span>
                </button>
              )}

              <button
                onClick={() => onBookConsultation && onBookConsultation('Financial Growth Consultation')}
                className="px-6 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 flex items-center justify-center gap-2"
              >
                <Calendar className="w-4 h-4 text-blue-400" />
                <span>Book 1-on-1 Consultation (Pre-Summary Attached)</span>
              </button>

              <button
                onClick={() => onOpenAcademy && onOpenAcademy()}
                className="px-6 py-3.5 rounded-xl bg-slate-900 text-slate-300 font-bold text-xs border border-slate-800 hover:text-white flex items-center justify-center gap-2"
              >
                <BookOpen className="w-4 h-4 text-emerald-400" />
                <span>Bammy Investment School</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VIEW MODE 4: ALGORITHMIC ASSET ALLOCATOR & YIELD SIMULATOR */}
      {activeMode === 'allocator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fadeIn">
          {/* Left Column: Interactive Wizard Controls */}
          <div className="lg:col-span-5 space-y-6 bg-slate-900/90 p-6 rounded-2xl border border-slate-800 shadow-xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Sliders className="w-5 h-5 text-blue-400" /> Yield & Allocation Parameters
              </h2>
              <span className="text-xs text-slate-400 font-semibold">Simulator</span>
            </div>

            {/* 1. Investment Amount */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Capital Amount to Deploy
                </label>
                <span className="text-lg font-extrabold text-blue-400 font-mono">
                  {formatCurrency(investmentNgn, currency)}
                </span>
              </div>

              <input
                type="range"
                min="2000"
                max="50000000"
                step="1000"
                value={investmentNgn}
                onChange={(e) => setInvestmentNgn(Number(e.target.value))}
                className="w-full accent-blue-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
              />

              <div className="flex flex-wrap gap-1.5 pt-1">
                {presetAmountsNgn.map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setInvestmentNgn(amt)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                      investmentNgn === amt
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
                    }`}
                  >
                    {amt === 2000 ? '₦2,000 (Min Ticket)' : formatCurrency(amt, currency)}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Primary Financial Goal */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Primary Financial Objective
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'preservation', title: 'Capital Safety', desc: '100% Sovereign T-Bills', icon: ShieldCheck },
                  { id: 'yield', title: 'Steady Cashflow', desc: 'Monthly/Quarterly Payouts', icon: DollarSign },
                  { id: 'growth', title: 'Capital Growth', desc: 'Real Estate & Debt Notes', icon: TrendingUp },
                  { id: 'ultra', title: 'High-Yield Private', desc: 'Venture & High ROI Debt', icon: Zap },
                ].map((goal) => {
                  const Icon = goal.icon;
                  const selected = primaryGoal === goal.id;
                  return (
                    <button
                      key={goal.id}
                      onClick={() => {
                        setPrimaryGoal(goal.id as any);
                        if (goal.id === 'preservation') setRiskTolerance('Conservative');
                        if (goal.id === 'yield') setRiskTolerance('Balanced');
                        if (goal.id === 'growth') setRiskTolerance('Growth');
                        if (goal.id === 'ultra') setRiskTolerance('High-Yield Private');
                      }}
                      className={`p-3 rounded-xl border text-left transition flex flex-col justify-between ${
                        selected
                          ? 'bg-blue-950/60 border-blue-500 text-white shadow-lg'
                          : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <Icon className={`w-4 h-4 ${selected ? 'text-blue-400' : 'text-slate-500'}`} />
                        {selected && <CheckCircle2 className="w-3.5 h-3.5 text-blue-400" />}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-200 mt-2">{goal.title}</p>
                        <p className="text-[10px] text-slate-400">{goal.desc}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Timeline Selection */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <label className="font-semibold text-slate-300 uppercase tracking-wider">
                  Investment Horizon
                </label>
                <span className="font-bold text-blue-400">{timelineYears} Year{timelineYears > 1 ? 's' : ''}</span>
              </div>
              <div className="flex gap-2">
                {[1, 2, 3, 5, 7].map((yr) => (
                  <button
                    key={yr}
                    onClick={() => setTimelineYears(yr)}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-medium transition ${
                      timelineYears === yr
                        ? 'bg-blue-600 text-white font-bold'
                        : 'bg-slate-950 text-slate-400 hover:bg-slate-800 border border-slate-800'
                    }`}
                  >
                    {yr} yr{yr > 1 ? 's' : ''}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Recommended Capital Allocation & Projected Growth */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-slate-900/90 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <span className="text-xs font-semibold text-blue-400 tracking-wider uppercase">
                    Recommended Strategy
                  </span>
                  <h3 className="text-xl font-extrabold text-white">
                    Optimal Capital Allocation Breakdown
                  </h3>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400">Target Weighted Return</span>
                  <p className="text-2xl font-black text-blue-400 font-mono">
                    {weightedYieldPcnt.toFixed(1)}% <span className="text-xs text-slate-400 font-normal">p.a.</span>
                  </p>
                </div>
              </div>

              {/* Pie Chart & Detailed Legend */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                <div className="md:col-span-5 h-56 relative flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={allocations}
                        cx="50%"
                        cy="50%"
                        innerRadius={55}
                        outerRadius={80}
                        paddingAngle={4}
                        dataKey="percentage"
                      >
                        {allocations.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip
                        formatter={(val: any) => [`${val}%`, 'Allocation']}
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute text-center">
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">Portfolio</span>
                    <span className="text-lg font-black text-white font-mono">{formatCurrency(investmentNgn, currency)}</span>
                  </div>
                </div>

                <div className="md:col-span-7 space-y-3">
                  {allocations.map((alloc, i) => (
                    <div key={alloc.category} className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: COLORS[i] }} />
                        <div className="truncate">
                          <p className="font-bold text-slate-200 truncate">{alloc.category}</p>
                          <p className="text-[10px] text-slate-400 truncate">{alloc.rationale}</p>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="font-extrabold text-white font-mono">{formatCurrency(alloc.recommendedNgn, currency)}</span>
                        <p className="text-[10px] text-blue-400 font-bold">{alloc.percentage}% split ({alloc.expectedYieldPcnt}% p.a.)</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Simulation Chart */}
              <div className="pt-4 border-t border-slate-800 space-y-3">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="text-sm font-bold text-slate-200 flex items-center gap-1.5">
                      <TrendingUp className="w-4 h-4 text-blue-400" /> Projected Wealth Compound Growth
                    </h4>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-slate-400">Projected Value</span>
                    <p className="text-lg font-bold text-blue-400 font-mono">
                      {formatCurrency(projectedEndBalanceNgn, currency)}
                    </p>
                  </div>
                </div>

                <div className="h-44 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={growthProjection}>
                      <defs>
                        <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#2563eb" stopOpacity={0.4} />
                          <stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                      <XAxis dataKey="year" stroke="#94a3b8" tickFormatter={(v) => `Yr ${v}`} />
                      <YAxis
                        stroke="#94a3b8"
                        tickFormatter={(v) => (v >= 1000000 ? `${(v / 1000000).toFixed(1)}M` : `${(v / 1000).toFixed(0)}k`)}
                      />
                      <Tooltip
                        formatter={(val: any) => [formatCurrency(val, currency), 'Portfolio Value']}
                        labelFormatter={(lbl) => `Year ${lbl}`}
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }}
                      />
                      <Area type="monotone" dataKey="balanceNgn" stroke="#3b82f6" strokeWidth={2.5} fillOpacity={1} fill="url(#colorBalance)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Deploy Button */}
              <div className="pt-2">
                <button
                  onClick={handleDeploy}
                  className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-blue-950 flex items-center justify-center gap-2 transition hover:scale-[1.01]"
                >
                  <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
                  <span>Deploy Allocation to Vetted Vaults</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
