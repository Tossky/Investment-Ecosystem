import React from 'react';
import { Currency } from '../types';
import {
  TrendingUp,
  Briefcase,
  PieChart,
  BookOpen,
  Calendar,
  Layers,
  Sparkles,
  ShieldCheck,
  Building2,
  Sliders,
  Wallet,
  Globe,
  Compass,
} from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  userRole: 'investor' | 'seeker' | 'advisor' | 'admin';
  setUserRole: (role: 'investor' | 'seeker' | 'advisor' | 'admin') => void;
  onOpenAiAssistant: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  currency,
  setCurrency,
  userRole,
  setUserRole,
  onOpenAiAssistant,
}) => {
  const navItems = [
    { id: 'matchmaker', label: 'AI Assessment', icon: Compass, badge: 'AI Pathway' },
    { id: 'marketplace', label: 'Opportunities', icon: TrendingUp, badge: 'Vetted Deals' },
    { id: 'investor-portal', label: 'My Portfolio', icon: PieChart },
    { id: 'seeker-portal', label: 'Business Funding', icon: Building2 },
    { id: 'growth-services', label: 'Growth Advisory', icon: Briefcase },
    { id: 'consultation', label: '1-on-1 Consult', icon: Calendar },
    { id: 'academy', label: 'Investment School', icon: BookOpen },
    { id: 'architecture', label: 'Admin & Compliance', icon: Layers, badge: 'Governance' },
  ];

  return (
    <header id="main-header" className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-800 text-slate-100 shadow-xl w-full max-w-full">
      {/* Top Utility Announcement Bar */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 px-4 py-1.5 border-b border-slate-800 text-xs text-slate-300 flex flex-wrap justify-between items-center gap-2 max-w-full">
        <div className="flex items-center gap-3">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 font-bold text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" /> SEC Regulatory Firewall & Disclosed Advisory
          </span>
          <span className="hidden sm:inline text-slate-400 font-medium text-[11px]">
            AI Strategy → Human Expertise → Licensed Partner Execution (Meristem Trustees SPV Custody)
          </span>
        </div>

        <div className="flex items-center gap-4 text-[11px]">
          {/* Currency Switcher */}
          <div className="flex items-center bg-slate-900 p-0.5 rounded-lg border border-slate-800">
            <button
              onClick={() => setCurrency('NGN')}
              className={`px-2.5 py-0.5 rounded font-bold transition ${
                currency === 'NGN' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              ₦ NGN
            </button>
            <button
              onClick={() => setCurrency('USD')}
              className={`px-2.5 py-0.5 rounded font-bold transition ${
                currency === 'USD' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              $ USD
            </button>
          </div>

          {/* Role Persona Switcher Sandbox */}
          <div className="flex items-center gap-1 bg-slate-900 px-2 py-0.5 rounded-lg border border-slate-800">
            <span className="text-slate-400 hidden md:inline font-medium">Persona:</span>
            <select
              value={userRole}
              onChange={(e) => setUserRole(e.target.value as any)}
              className="bg-transparent text-blue-400 text-xs font-bold focus:outline-none cursor-pointer"
            >
              <option value="investor" className="bg-slate-900 text-white">Investor Mode</option>
              <option value="seeker" className="bg-slate-900 text-white">Business / Capital Seeker</option>
              <option value="advisor" className="bg-slate-900 text-white">Growth Advisor</option>
              <option value="admin" className="bg-slate-900 text-white">Admin & Investment Committee</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Header Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between gap-4 w-full">
        {/* Logo */}
        <div
          onClick={() => setActiveTab('matchmaker')}
          className="flex items-center gap-3 cursor-pointer group shrink-0"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 p-0.5 shadow-md shadow-blue-900/30 group-hover:scale-105 transition-transform flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-xl tracking-tight text-white font-mono">
                Bammy<span className="text-blue-500">Growth</span>
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-400 font-bold border border-blue-500/30">
                HUB
              </span>
            </div>
            <p className="text-[10px] text-slate-400 tracking-wider uppercase font-semibold">
              Financial Growth Ecosystem
            </p>
          </div>
        </div>

        {/* Center Nav Items */}
        <nav className="hidden xl:flex items-center gap-1 bg-slate-900/90 p-1.5 rounded-xl border border-slate-800">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-2 transition ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-900/40'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/80'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                      isActive ? 'bg-blue-800 text-blue-100' : 'bg-slate-800 text-blue-400 border border-blue-500/30'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Right CTA / Controls */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* AI Co-Pilot Button */}
          <button
            onClick={onOpenAiAssistant}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs shadow-md shadow-blue-900/40 transition-all hover:scale-105 border border-blue-400/30"
          >
            <Sparkles className="w-3.5 h-3.5 animate-pulse text-amber-300" />
            <span className="hidden sm:inline">AI Growth Co-Pilot</span>
          </button>

          {/* User Profile / KYC Pill */}
          <div className="flex items-center gap-2.5 pl-3 border-l border-slate-800">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 font-bold text-xs">
              BG
            </div>
            <div className="hidden xl:block text-left text-xs">
              <p className="font-bold text-white">Member Profile</p>
              <div className="flex items-center gap-1 text-[10px] text-emerald-400 font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                <span>Tier 2 Verified</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile / Tablet Sub-Nav Slider */}
      <div className="xl:hidden flex overflow-x-auto gap-2 px-4 py-2 border-t border-slate-800 bg-slate-900 scrollbar-none max-w-full">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                isActive ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-300'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};

