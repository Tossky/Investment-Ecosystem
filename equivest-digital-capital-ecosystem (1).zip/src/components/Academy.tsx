import React, { useState } from 'react';
import { LearningArticle, Currency } from '../types';
import { MOCK_ARTICLES } from '../data/mockData';
import {
  BookOpen,
  Video,
  ShieldCheck,
  FileText,
  Lock,
  Search,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  UserCheck,
  AlertTriangle,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface AcademyProps {
  currency: Currency;
}

export const Academy: React.FC<AcademyProps> = () => {
  const [selectedArticle, setSelectedArticle] = useState<LearningArticle | null>(null);
  const [activeKycTier, setActiveKycTier] = useState<number>(2);
  const [kycSuccessMsg, setKycSuccessMsg] = useState<string | null>(null);

  const handleSimulateKycUpgrade = (targetTier: number) => {
    confetti({ particleCount: 70, spread: 60, origin: { y: 0.6 } });
    setActiveKycTier(targetTier);
    setKycSuccessMsg(`KYC Status upgraded to Tier ${targetTier}! Investment ticket limits increased.`);
    setTimeout(() => setKycSuccessMsg(null), 3000);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <BookOpen className="w-3.5 h-3.5 text-blue-400" /> EquiVest Learning & Regulatory Center
          </div>
          <h1 className="text-2xl font-extrabold text-white mt-1">
            Capital Literacy, Masterclasses & Regulatory Compliance
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Empowering investors with asset literacy while upholding SEC/CBN regulatory compliance, bank-grade KYC, and investor risk protection.
          </p>
        </div>
      </div>

      {/* KYC Verification & SEC Compliance Hub */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-6">
        <div className="flex justify-between items-center pb-3 border-b border-slate-800">
          <div>
            <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
              Identity & Compliance Framework
            </span>
            <h2 className="text-lg font-extrabold text-white">Tiered KYC Verification Status Simulator</h2>
          </div>
          <span className="text-xs text-emerald-400 font-bold bg-emerald-950 px-3 py-1 rounded-lg border border-emerald-800">
            Current: Tier {activeKycTier} Verified ✓
          </span>
        </div>

        {kycSuccessMsg && (
          <div className="p-3 bg-emerald-950 border border-emerald-500 rounded-xl text-xs text-emerald-300 font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{kycSuccessMsg}</span>
          </div>
        )}

        {/* Tier Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Tier 1 */}
          <div className={`p-4 rounded-xl border space-y-3 ${activeKycTier >= 1 ? 'bg-slate-950 border-emerald-500/50' : 'bg-slate-950/50 border-slate-800'}`}>
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-200">Tier 1: Basic Identity</span>
              {activeKycTier >= 1 && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
            </div>
            <p className="text-[11px] text-slate-400">BVN / NIN Hash + Verified Phone Number.</p>
            <div className="p-2 bg-slate-900 rounded text-[10px] text-slate-300 font-mono">
              Limit: Up to ₦500,000 / deal
            </div>
          </div>

          {/* Tier 2 */}
          <div className={`p-4 rounded-xl border space-y-3 ${activeKycTier >= 2 ? 'bg-slate-950 border-emerald-500/50' : 'bg-slate-950/50 border-slate-800'}`}>
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-200">Tier 2: Government ID & Address</span>
              {activeKycTier >= 2 && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
            </div>
            <p className="text-[11px] text-slate-400">National ID Card / Passport + Utility Bill Verification.</p>
            <div className="p-2 bg-slate-900 rounded text-[10px] text-emerald-400 font-mono font-bold">
              Limit: Up to ₦20,000,000 / deal
            </div>
            {activeKycTier < 2 && (
              <button
                onClick={() => handleSimulateKycUpgrade(2)}
                className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded"
              >
                Verify Tier 2
              </button>
            )}
          </div>

          {/* Tier 3 */}
          <div className={`p-4 rounded-xl border space-y-3 ${activeKycTier >= 3 ? 'bg-slate-950 border-emerald-500/50' : 'bg-slate-950/50 border-slate-800'}`}>
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-200">Tier 3: Accredited Investor</span>
              {activeKycTier >= 3 && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
            </div>
            <p className="text-[11px] text-slate-400">Net Worth Attestation (₦50M+ liquid assets or corporate account).</p>
            <div className="p-2 bg-slate-900 rounded text-[10px] text-amber-400 font-mono font-bold">
              Limit: Unlimited Institutional Access
            </div>
            {activeKycTier < 3 && (
              <button
                onClick={() => handleSimulateKycUpgrade(3)}
                className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded"
              >
                Simulate Tier 3 Verification
              </button>
            )}
          </div>
        </div>

        {/* Regulatory & Risk Disclosures Box */}
        <div className="p-4 bg-emerald-950/30 border border-emerald-900 rounded-xl space-y-2 text-xs">
          <h4 className="font-bold text-emerald-300 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" /> Statutory Risk Disclosure & Custody Guarantee
          </h4>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            EquiVest operates in strict compliance with Securities & Exchange Commission (SEC) guidelines on collective investment schemes and crowdfunding SPVs. Past yield performance is not a guarantee of future returns. Principal capital in non-money-market instruments carries investment risk. Assets are held in independent trust vaults managed by Meristem Trustees Ltd.
          </p>
        </div>
      </div>

      {/* Learning Center Articles & Masterclasses Grid */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-emerald-400" /> Masterclasses & Articles Library
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {MOCK_ARTICLES.map((art) => (
            <div
              key={art.id}
              onClick={() => setSelectedArticle(art)}
              className="bg-slate-900 rounded-2xl border border-slate-800 hover:border-emerald-500/50 transition duration-300 overflow-hidden cursor-pointer flex flex-col justify-between shadow-xl group"
            >
              <div>
                <div className="relative h-44 overflow-hidden bg-slate-950">
                  <img
                    src={art.featuredImage}
                    alt={art.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-80"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent" />
                  <span className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-slate-950/90 border border-slate-700 text-emerald-400 font-bold text-[10px]">
                    {art.category}
                  </span>
                  {art.isMasterclassVideo && (
                    <span className="absolute top-3 right-3 px-2.5 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[10px] flex items-center gap-1">
                      <Video className="w-3 h-3" /> Masterclass Video
                    </span>
                  )}
                </div>

                <div className="p-5 space-y-2">
                  <h3 className="font-bold text-white text-base group-hover:text-emerald-400 transition-colors line-clamp-2">
                    {art.title}
                  </h3>
                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{art.summary}</p>
                </div>
              </div>

              <div className="p-5 pt-0 flex justify-between items-center text-[11px] text-slate-400 border-t border-slate-800/60 mt-2">
                <span>By {art.author}</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  Read Article <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Article Detail Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative my-8">
            <button
              onClick={() => setSelectedArticle(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition text-xs font-bold"
            >
              ✕ Close
            </button>

            <div className="space-y-2">
              <span className="px-2.5 py-1 rounded-lg bg-emerald-950 border border-emerald-800 text-emerald-400 font-bold text-xs">
                {selectedArticle.category}
              </span>
              <h2 className="text-xl font-extrabold text-white mt-1">{selectedArticle.title}</h2>
              <div className="flex items-center gap-3 text-xs text-slate-400">
                <span>Author: {selectedArticle.author}</span>
                <span>•</span>
                <span>{selectedArticle.readTimeMinutes} min read</span>
                <span>•</span>
                <span>{selectedArticle.publishedDate}</span>
              </div>
            </div>

            <div className="rounded-xl overflow-hidden h-52 bg-slate-950">
              <img
                src={selectedArticle.featuredImage}
                alt={selectedArticle.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="text-xs text-slate-300 leading-relaxed whitespace-pre-line space-y-4">
              {selectedArticle.content}
            </div>

            <div className="pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedArticle(null)}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs"
              >
                Close Article
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
