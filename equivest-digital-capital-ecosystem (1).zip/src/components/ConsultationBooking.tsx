import React, { useState } from 'react';
import { AdvisoryConsultant, Currency } from '../types';
import { MOCK_CONSULTANTS } from '../data/mockData';
import { formatCurrency } from '../utils/formatters';
import {
  Calendar,
  Clock,
  UserCheck,
  Star,
  CheckCircle2,
  Video,
  FileText,
  ShieldCheck,
  ArrowRight,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface ConsultationBookingProps {
  currency: Currency;
  preSelectedTopic?: string;
}

export const ConsultationBooking: React.FC<ConsultationBookingProps> = ({
  currency,
  preSelectedTopic,
}) => {
  const [selectedConsultant, setSelectedConsultant] = useState<AdvisoryConsultant>(MOCK_CONSULTANTS[0]);
  const [selectedDate, setSelectedDate] = useState<string>('2026-08-04');
  const [selectedSlot, setSelectedSlot] = useState<string>('10:00 AM');
  const [consultScope, setConsultScope] = useState<string>(preSelectedTopic || 'Wealth Strategy & Asset Matchmaking');
  const [notes, setNotes] = useState<string>('');
  const [isBooked, setIsBooked] = useState<boolean>(false);

  const availableSlots = ['09:00 AM', '10:00 AM', '11:30 AM', '02:00 PM', '04:00 PM'];
  const dates = [
    { dayName: 'Mon', dateStr: '2026-08-03' },
    { dayName: 'Tue', dateStr: '2026-08-04' },
    { dayName: 'Wed', dateStr: '2026-08-05' },
    { dayName: 'Thu', dateStr: '2026-08-06' },
    { dayName: 'Fri', dateStr: '2026-08-07' },
  ];

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    confetti({
      particleCount: 90,
      spread: 70,
      origin: { y: 0.6 },
    });
    setIsBooked(true);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <Calendar className="w-3.5 h-3.5 text-blue-400" /> 1-on-1 Executive Consultation
          </div>
          <h1 className="text-2xl font-extrabold text-white mt-1">
            Book 1-on-1 Session with Certified Capital Advisors
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Schedule private consultations with Chartered Financial Analysts (CFAs), SEC legal structuring partners, and SME growth advisors.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-950 px-3.5 py-2 rounded-xl border border-slate-800 text-xs text-blue-400 font-bold">
          <Video className="w-4 h-4 text-blue-400" />
          <span>Encrypted Google Meet & In-Person Lagos Office</span>
        </div>
      </div>

      {isBooked ? (
        <div className="max-w-2xl mx-auto p-8 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-center space-y-4 animate-fadeIn">
          <div className="w-16 h-16 rounded-full bg-emerald-950 border-2 border-emerald-500 flex items-center justify-center mx-auto text-emerald-400">
            <CheckCircle2 className="w-10 h-10" />
          </div>
          <h2 className="text-2xl font-extrabold text-white">Consultation Confirmed!</h2>
          <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
            Your 1-on-1 private advisory session with <strong>{selectedConsultant.name}</strong> is scheduled for{' '}
            <strong className="text-emerald-400">{selectedDate} at {selectedSlot}</strong>.
          </p>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs text-left max-w-md mx-auto space-y-2">
            <div className="flex justify-between text-slate-400">
              <span>Advisor:</span>
              <span className="font-bold text-slate-200">{selectedConsultant.name}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Scope:</span>
              <span className="font-bold text-emerald-400">{consultScope}</span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Video Link:</span>
              <span className="font-mono text-blue-400 underline">https://meet.google.com/eqv-consult-88</span>
            </div>
          </div>

          <button
            onClick={() => setIsBooked(false)}
            className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition"
          >
            Book Another Consultation
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left: Consultant Selection */}
          <div className="lg:col-span-6 space-y-4">
            <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
              1. Select Advisory Specialist
            </h3>

            <div className="space-y-4">
              {MOCK_CONSULTANTS.map((c) => {
                const isSelected = selectedConsultant.id === c.id;
                return (
                  <div
                    key={c.id}
                    onClick={() => setSelectedConsultant(c)}
                    className={`p-5 rounded-2xl border cursor-pointer transition-all flex items-start gap-4 ${
                      isSelected
                        ? 'bg-emerald-950/40 border-emerald-500 shadow-xl'
                        : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <img
                      src={c.avatar}
                      alt={c.name}
                      className="w-14 h-14 rounded-xl object-cover shrink-0 border border-slate-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="space-y-1 flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <h4 className="font-bold text-white text-base truncate">{c.name}</h4>
                        <span className="flex items-center gap-1 text-xs font-bold text-amber-400">
                          <Star className="w-3.5 h-3.5 fill-amber-400" /> {c.rating} ({c.reviewsCount})
                        </span>
                      </div>
                      <p className="text-xs text-emerald-400 font-semibold">{c.title}</p>
                      <p className="text-[11px] text-slate-400 line-clamp-1">{c.credentials}</p>
                      <div className="pt-2 flex justify-between items-center text-xs">
                        <span className="text-slate-400 text-[10px]">Specialization: {c.specialization}</span>
                        <span className="font-bold text-white font-mono">{formatCurrency(c.hourlyRateNgn, currency)}/hr</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Date, Time & Intake Form */}
          <div className="lg:col-span-6 space-y-6 bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl">
            <h3 className="text-sm font-bold text-slate-200 uppercase tracking-wider">
              2. Choose Slot & Consultation Scope
            </h3>

            <form onSubmit={handleBooking} className="space-y-5 text-xs">
              {/* Date Selection */}
              <div className="space-y-2">
                <label className="block text-slate-300 font-semibold">Select Date</label>
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {dates.map((d) => (
                    <button
                      key={d.dateStr}
                      type="button"
                      onClick={() => setSelectedDate(d.dateStr)}
                      className={`flex-1 py-2 px-3 rounded-xl border text-center transition shrink-0 ${
                        selectedDate === d.dateStr
                          ? 'bg-emerald-600 border-emerald-500 text-white font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <span className="block text-[10px] uppercase font-semibold">{d.dayName}</span>
                      <span className="block font-extrabold text-sm">{d.dateStr.split('-')[2]} Aug</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Time Slot Selection */}
              <div className="space-y-2">
                <label className="block text-slate-300 font-semibold">Select Time Slot</label>
                <div className="grid grid-cols-3 gap-2">
                  {availableSlots.map((slot) => (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => setSelectedSlot(slot)}
                      className={`py-2 px-2 rounded-xl border text-center transition ${
                        selectedSlot === slot
                          ? 'bg-emerald-600 border-emerald-500 text-white font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>

              {/* Consultation Scope */}
              <div className="space-y-2">
                <label className="block text-slate-300 font-semibold">Consultation Subject & Scope</label>
                <select
                  value={consultScope}
                  onChange={(e) => setConsultScope(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-emerald-500"
                >
                  <option value="Wealth Strategy & Asset Matchmaking">Wealth Strategy & Asset Matchmaking</option>
                  <option value="SME Capital Raising & Pitch Review">SME Capital Raising & Pitch Review</option>
                  <option value="SEC SPV Trust Legal Structuring">SEC SPV Trust Legal Structuring</option>
                  <option value="Tax Optimization for Yield Portfolios">Tax Optimization for Yield Portfolios</option>
                </select>
              </div>

              {/* Pre-Consultation Notes */}
              <div className="space-y-2">
                <label className="block text-slate-300 font-semibold">Pre-Consultation Background Notes</label>
                <textarea
                  rows={3}
                  placeholder="Share details regarding your capital allocation goals or business raise..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Fee & Submit */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block">Session Duration: 45 Minutes</span>
                  <span className="font-bold text-white font-mono text-sm">
                    Fee: {formatCurrency(selectedConsultant.hourlyRateNgn, currency)}
                  </span>
                </div>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-lg transition flex items-center gap-2"
                >
                  <span>Confirm Booking</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
