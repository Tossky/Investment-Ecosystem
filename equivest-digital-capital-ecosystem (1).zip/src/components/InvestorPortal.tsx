import React, { useState } from 'react';
import { UserInvestment, Currency } from '../types';
import { formatCurrency } from '../utils/formatters';
import {
  PieChart as PieChartIcon,
  TrendingUp,
  Wallet,
  Calendar,
  Download,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  FileText,
  DollarSign,
  Activity,
  Lock,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

interface InvestorPortalProps {
  currency: Currency;
  userInvestments: UserInvestment[];
}

export const InvestorPortal: React.FC<InvestorPortalProps> = ({
  currency,
  userInvestments,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Calculate Summary Totals
  const walletCashBalanceNgn = 2500000;
  const totalInvestedNgn = userInvestments.reduce((sum, inv) => sum + inv.amountNgn, 0);
  const totalYieldEarnedNgn = userInvestments.reduce((sum, inv) => sum + inv.yieldEarnedToDateNgn, 0);
  const totalNetPortfolioNgn = walletCashBalanceNgn + totalInvestedNgn + totalYieldEarnedNgn;

  // Chart Data: Portfolio Yield History (Jan - July 2026)
  const yieldHistory = [
    { month: 'Jan', yieldNgn: 4200, balanceNgn: 500000 },
    { month: 'Feb', yieldNgn: 11500, balanceNgn: 650000 },
    { month: 'Mar', yieldNgn: 24000, balanceNgn: 720000 },
    { month: 'Apr', yieldNgn: 41000, balanceNgn: 800000 },
    { month: 'May', yieldNgn: 58000, balanceNgn: 820000 },
    { month: 'Jun', yieldNgn: 69000, balanceNgn: 840000 },
    { month: 'Jul', yieldNgn: totalYieldEarnedNgn, balanceNgn: totalInvestedNgn },
  ];

  // Pie Chart Data by Category
  const categoryTotals: Record<string, number> = {};
  userInvestments.forEach((inv) => {
    categoryTotals[inv.category] = (categoryTotals[inv.category] || 0) + inv.amountNgn;
  });

  const pieData = Object.keys(categoryTotals).map((cat) => ({
    name: cat,
    value: categoryTotals[cat],
  }));

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#8b5cf6'];

  const handleDownloadReport = () => {
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Top Welcome Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl">
        <div>
          <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">
            Investor Portfolio Vault
          </span>
          <h1 className="text-2xl font-extrabold text-white mt-1">
            Portfolio Snapshot & Yield Monitor
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Real-time tracking of active fractional holdings, quarterly cash distributions, and SEC trustee escrow balances.
          </p>
        </div>

        <button
          onClick={handleDownloadReport}
          className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition flex items-center gap-2 shrink-0"
        >
          <Download className="w-4 h-4 text-white" />
          <span>Download SEC Audit & Tax Certificate</span>
        </button>
      </div>

      {downloadSuccess && (
        <div className="p-3 bg-emerald-950/80 border border-emerald-500 rounded-xl text-xs text-emerald-300 font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>Audit Certificate PDF successfully generated and downloaded to your browser!</span>
        </div>
      )}

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Portfolio */}
        <div className="p-5 bg-slate-900 rounded-2xl border border-slate-800 shadow-xl space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-400">
            <span>Total Portfolio Net Worth</span>
            <Wallet className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-white font-mono">
            {formatCurrency(totalNetPortfolioNgn, currency)}
          </p>
          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>+19.4% Weighted Annual Return</span>
          </div>
        </div>

        {/* Liquid Cash Wallet */}
        <div className="p-5 bg-slate-900 rounded-2xl border border-slate-800 shadow-xl space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-400">
            <span>Uninvested Cash Wallet</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-black text-emerald-400 font-mono">
            {formatCurrency(walletCashBalanceNgn, currency)}
          </p>
          <p className="text-[11px] text-slate-400">Available for instant deployment</p>
        </div>

        {/* Active Locked Capital */}
        <div className="p-5 bg-slate-900 rounded-2xl border border-slate-800 shadow-xl space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-400">
            <span>Active Allocated Capital</span>
            <Lock className="w-4 h-4 text-blue-400" />
          </div>
          <p className="text-2xl font-black text-white font-mono">
            {formatCurrency(totalInvestedNgn, currency)}
          </p>
          <p className="text-[11px] text-slate-400">{userInvestments.length} Active Vault Assets</p>
        </div>

        {/* Cumulative Yield Earned */}
        <div className="p-5 bg-slate-900 rounded-2xl border border-slate-800 shadow-xl space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-400">
            <span>Total Yield Earned to Date</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-black text-amber-400 font-mono">
            + {formatCurrency(totalYieldEarnedNgn, currency)}
          </p>
          <p className="text-[11px] text-emerald-400 font-medium">Payouts deposited directly to wallet</p>
        </div>
      </div>

      {/* Analytics Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Yield Growth History Chart */}
        <div className="lg:col-span-8 bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-emerald-400" /> Historical Monthly Yield Performance
              </h3>
              <p className="text-xs text-slate-400">Cumulative cash distributions earned in 2026</p>
            </div>
            <span className="text-xs text-emerald-400 font-bold bg-emerald-950 px-2.5 py-1 rounded-lg border border-emerald-800">
              Auto-Compounding Active
            </span>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={yieldHistory}>
                <defs>
                  <linearGradient id="yieldGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis dataKey="month" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <Tooltip
                  formatter={(val: any) => [formatCurrency(val, currency), 'Yield Accumulated']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }}
                />
                <Area type="monotone" dataKey="yieldNgn" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#yieldGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Asset Category Distribution Pie */}
        <div className="lg:col-span-4 bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <PieChartIcon className="w-4 h-4 text-emerald-400" /> Portfolio Diversification
            </h3>
            <p className="text-xs text-slate-400">Distribution across asset classes</p>
          </div>

          <div className="h-44 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={40} outerRadius={65} paddingAngle={4} dataKey="value">
                  {pieData.map((entry, index) => (
                    <Cell key={`c-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => [formatCurrency(val, currency), 'Allocated']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-1.5 text-xs">
            {pieData.map((p, i) => (
              <div key={p.name} className="flex justify-between items-center">
                <span className="flex items-center gap-2 text-slate-300">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i] }} />
                  {p.name}
                </span>
                <span className="font-bold text-white font-mono">{formatCurrency(p.value, currency)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Active Holdings Table & Upcoming Payout Schedule */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-xl p-6 space-y-4">
        <div className="flex justify-between items-center pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-white">Active Asset Holdings & Payout Schedule</h3>
            <p className="text-xs text-slate-400">Immutable ledger records managed under bankruptcy-remote SPV trusts</p>
          </div>
          <span className="text-xs text-slate-400">{userInvestments.length} Holdings</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase font-semibold text-[10px] tracking-wider">
              <tr>
                <th className="p-3.5 rounded-l-xl">Asset / Opportunity Title</th>
                <th className="p-3.5">Category</th>
                <th className="p-3.5">Principal Invested</th>
                <th className="p-3.5">Yield Earned</th>
                <th className="p-3.5">Next Payout Date</th>
                <th className="p-3.5 text-right rounded-r-xl">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {userInvestments.map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-800/40 transition">
                  <td className="p-3.5 font-bold text-slate-100 max-w-xs truncate">
                    {inv.opportunityTitle}
                  </td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-emerald-400 font-semibold text-[11px]">
                      {inv.category}
                    </span>
                  </td>
                  <td className="p-3.5 font-mono font-bold text-white">
                    {formatCurrency(inv.amountNgn, currency)}
                  </td>
                  <td className="p-3.5 font-mono font-bold text-emerald-400">
                    +{formatCurrency(inv.yieldEarnedToDateNgn, currency)}
                  </td>
                  <td className="p-3.5">
                    <div className="flex items-center gap-1.5 text-slate-300">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span>{inv.nextPayoutDate}</span>
                    </div>
                  </td>
                  <td className="p-3.5 text-right">
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold text-[10px]">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" /> {inv.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
