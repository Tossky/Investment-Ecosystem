import React, { useState } from 'react';
import { MOCK_SCHEMA_TABLES, MOCK_SYSTEM_PIPELINES } from '../data/mockData';
import {
  Layers,
  Database,
  Cpu,
  ShieldCheck,
  Workflow,
  Copy,
  CheckCircle2,
  Server,
  Lock,
  ArrowRight,
  Code2,
  FileCode,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const ArchitectureBlueprint: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'schema' | 'architecture' | 'pipelines' | 'compliance'>('schema');
  const [copiedSchema, setCopiedSchema] = useState(false);

  const generateSqlDdl = (): string => {
    return MOCK_SCHEMA_TABLES.map((tbl) => {
      const cols = tbl.columns
        .map((c) => `  ${c.name} ${c.type} ${c.constraints}`)
        .join(',\n');
      return `-- Table: ${tbl.name}\n-- ${tbl.description}\nCREATE TABLE ${tbl.name} (\n${cols}\n);`;
    }).join('\n\n');
  };

  const handleCopyDdl = () => {
    if (navigator && navigator.clipboard) {
      navigator.clipboard.writeText(generateSqlDdl()).catch(() => {});
    }
    setCopiedSchema(true);
    confetti({ particleCount: 50, spread: 50, origin: { y: 0.6 } });
    setTimeout(() => setCopiedSchema(false), 2500);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <Layers className="w-3.5 h-3.5 text-blue-400" /> Technical System Blueprint
          </div>
          <h1 className="text-2xl font-extrabold text-white mt-1">
            EquiVest Architecture & Business Engine Specifications
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Inspect the underlying database schema, microservice data pipelines, risk scoring algorithms, and SEC compliance architecture.
          </p>
        </div>

        <button
          onClick={handleCopyDdl}
          className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition flex items-center gap-2 shrink-0"
        >
          {copiedSchema ? <CheckCircle2 className="w-4 h-4 text-white" /> : <Copy className="w-4 h-4" />}
          <span>{copiedSchema ? 'SQL DDL Schema Copied!' : 'Export PostgreSQL DDL Schema'}</span>
        </button>
      </div>

      {/* Blueprint Sub-Tabs */}
      <div className="flex border-b border-slate-800 overflow-x-auto gap-2 scrollbar-none">
        {[
          { id: 'schema', label: 'Database Schema (ERD)', icon: Database },
          { id: 'architecture', label: 'Microservice System Flow', icon: Server },
          { id: 'pipelines', label: 'Workflow & Capital Pipelines', icon: Workflow },
          { id: 'compliance', label: 'SEC & Risk Matrix', icon: ShieldCheck },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-3 text-xs font-bold flex items-center gap-2 border-b-2 transition whitespace-nowrap ${
                isActive
                  ? 'border-blue-500 text-blue-400 bg-slate-900/80 rounded-t-xl'
                  : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: DATABASE SCHEMA (ERD) */}
      {activeTab === 'schema' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {MOCK_SCHEMA_TABLES.map((table) => (
              <div key={table.name} className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-emerald-400" />
                    <h3 className="text-base font-extrabold text-white font-mono">{table.name}</h3>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-400 font-mono">
                    {table.columns.length} columns
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">{table.description}</p>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-[11px] text-slate-300">
                    <thead className="bg-slate-950 text-slate-400 uppercase font-mono text-[9px]">
                      <tr>
                        <th className="p-2 font-bold">Column</th>
                        <th className="p-2 font-bold">Type</th>
                        <th className="p-2 font-bold">Constraints</th>
                        <th className="p-2 font-bold">Purpose</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {table.columns.map((col) => (
                        <tr key={col.name} className="hover:bg-slate-800/40 font-mono">
                          <td className="p-2 font-bold text-emerald-400">{col.name}</td>
                          <td className="p-2 text-slate-300">{col.type}</td>
                          <td className="p-2 text-amber-400 text-[10px]">{col.constraints}</td>
                          <td className="p-2 text-slate-400 font-sans text-[11px]">{col.description}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: MICROSERVICE ARCHITECTURE FLOW */}
      {activeTab === 'architecture' && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-xl space-y-6">
          <div>
            <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
              Scalable Cloud Run Architecture
            </span>
            <h3 className="text-xl font-extrabold text-white mt-1">High-Throughput Capital Engine Flow</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center text-xs">
            {/* Layer 1 */}
            <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-center">
              <div className="w-10 h-10 rounded-lg bg-emerald-950 border border-emerald-800 flex items-center justify-center mx-auto text-emerald-400">
                <Code2 className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-white">1. Client Tier (React / Vite SPA)</h4>
              <p className="text-[11px] text-slate-400">Matchmaker Wizard, ₦2k Fractional Vault UI, Investor Dashboard</p>
            </div>

            {/* Arrow */}
            <div className="hidden md:flex justify-center text-emerald-400">
              <ArrowRight className="w-6 h-6" />
            </div>

            {/* Layer 2 */}
            <div className="p-5 bg-slate-950 rounded-xl border border-emerald-500/40 space-y-2 text-center">
              <div className="w-10 h-10 rounded-lg bg-emerald-950 border border-emerald-500 flex items-center justify-center mx-auto text-emerald-400">
                <Cpu className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-white">2. Core API & Matchmaking Engine</h4>
              <p className="text-[11px] text-slate-400">Algorithmic Asset Allocator, Gemini AI Due Diligence Agent, Credit Bureau Integration</p>
            </div>

            {/* Arrow */}
            <div className="hidden md:flex justify-center text-emerald-400">
              <ArrowRight className="w-6 h-6" />
            </div>

            {/* Layer 3 */}
            <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-center">
              <div className="w-10 h-10 rounded-lg bg-blue-950 border border-blue-800 flex items-center justify-center mx-auto text-blue-400">
                <Lock className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-white">3. Escrow Vault & SPV Trustee Layer</h4>
              <p className="text-[11px] text-slate-400">Providus Bank Escrow Custody, Meristem SPV Trust Ledger, Auto Coupon Payouts</p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: WORKFLOW PIPELINES */}
      {activeTab === 'pipelines' && (
        <div className="space-y-6">
          {MOCK_SYSTEM_PIPELINES.map((pipe) => (
            <div key={pipe.id} className="bg-slate-900 rounded-2xl border border-slate-800 p-6 shadow-xl space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-slate-800">
                <h3 className="text-base font-extrabold text-white">{pipe.title}</h3>
                <span className="text-xs px-2.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                  {pipe.category}
                </span>
              </div>

              <div className="space-y-3">
                {pipe.steps.map((st) => (
                  <div key={st.stepNumber} className="flex items-start gap-3 p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-xs">
                    <span className="w-6 h-6 rounded-full bg-emerald-600 text-white font-black flex items-center justify-center text-[11px] shrink-0">
                      {st.stepNumber}
                    </span>
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{st.title}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-900 text-slate-400 border border-slate-700 font-mono">
                          Actor: {st.actor}
                        </span>
                      </div>
                      <p className="text-slate-400 text-[11px]">{st.systemAction}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 4: COMPLIANCE MATRIX */}
      {activeTab === 'compliance' && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-xl space-y-6">
          <div>
            <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
              Regulatory Enforcement Architecture
            </span>
            <h3 className="text-xl font-extrabold text-white mt-1">SEC / CBN Compliance Audit Checklist</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <h4 className="font-bold text-emerald-400 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4" /> SEC Crowdfunding & SPV Framework
              </h4>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Enforces retail ticket caps based on user KYC Tier. Fractional SPVs are legally registered with CAC and audited by licensed trustees.
              </p>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <h4 className="font-bold text-emerald-400 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4" /> Anti-Money Laundering (AML) & Sanctions
              </h4>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                Real-time BVN/NIN hashing against NIBSS databases. Automated NFIU suspicious transaction reporting thresholds.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
