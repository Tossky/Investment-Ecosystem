import React from 'react';
import { TrendingUp, ShieldCheck, Lock, ExternalLink } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-xs py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Col */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white font-black shadow-md shadow-blue-900/30">
                <TrendingUp className="w-5 h-5 text-white" />
              </div>
              <span className="font-extrabold text-lg text-white font-mono">
                Bammy<span className="text-blue-400">Growth</span>
              </span>
            </div>
            <p className="text-[11px] leading-relaxed">
              Bammy Growth Hub is an AI-first Financial Growth, Investment Intelligence and Business Opportunity Ecosystem.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3">Ecosystem</h4>
            <ul className="space-y-2 text-[11px]">
              <li className="hover:text-blue-400 cursor-pointer transition-colors">AI Financial Discovery</li>
              <li className="hover:text-blue-400 cursor-pointer transition-colors">5 Personal Growth Pathways</li>
              <li className="hover:text-blue-400 cursor-pointer transition-colors">Business Capital & Due Diligence</li>
              <li className="hover:text-blue-400 cursor-pointer transition-colors">Investment School & SEC Disclosures</li>
            </ul>
          </div>

          {/* Regulatory & Trustee */}
          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3">Custody & Protection</h4>
            <ul className="space-y-2 text-[11px]">
              <li className="flex items-center gap-1.5"><ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> SEC Regulatory Firewall Architecture</li>
              <li className="flex items-center gap-1.5"><Lock className="w-3.5 h-3.5 text-blue-400" /> SPV Trustee: Meristem Trustees Ltd</li>
              <li className="flex items-center gap-1.5"><ShieldCheck className="w-3.5 h-3.5 text-amber-400" /> Human Investment Committee Governance</li>
            </ul>
          </div>

          {/* Contact & Address */}
          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3">Headquarters</h4>
            <p className="text-[11px] leading-relaxed">
              Level 14, Eko Towers II, Adetokunbo Ademola Street, Victoria Island, Lagos, Nigeria.
            </p>
            <p className="text-[11px] mt-2 font-mono text-blue-400">advisory@bammygrowth.com</p>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row justify-between items-center gap-3 text-[11px] text-slate-500">
          <p>© 2026 Bammy Growth Hub. All Rights Reserved. Compliant with SEC & CBN Advisory Frameworks.</p>
          <div className="flex gap-4">
            <span className="hover:text-slate-300 cursor-pointer">Privacy Policy</span>
            <span className="hover:text-slate-300 cursor-pointer">Terms of Trust</span>
            <span className="hover:text-slate-300 cursor-pointer">SEC Risk Disclosure</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

