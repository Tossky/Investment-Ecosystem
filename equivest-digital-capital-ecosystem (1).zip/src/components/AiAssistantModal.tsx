import React, { useState } from 'react';
import { askEquiVestAiAssistant } from '../services/geminiService';
import { Sparkles, Send, Bot, User, X, Loader2, ShieldCheck } from 'lucide-react';

interface AiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  sender: 'user' | 'ai';
  text: string;
  time: string;
}

export const AiAssistantModal: React.FC<AiAssistantModalProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'ai',
      text: 'Hello! I am **EquiVest AI Co-Pilot**. How can I assist you today? You can ask me to evaluate an investment opportunity, explain fractional ₦2,000 real estate vaults, or recommend an optimal SME capital structure.',
      time: 'Just now',
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputQuery.trim() || loading) return;

    const userMsg = inputQuery.trim();
    setInputQuery('');

    const newMsgs: Message[] = [
      ...messages,
      { sender: 'user', text: userMsg, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
    ];
    setMessages(newMsgs);
    setLoading(true);

    try {
      const aiReply = await askEquiVestAiAssistant(userMsg);
      setMessages((prev) => [
        ...prev,
        { sender: 'ai', text: aiReply, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { sender: 'ai', text: 'Apologies, I encountered a temporary connection issue. Please try asking again.', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const sampleQuestions = [
    'How do fractional ₦2,000 pooled real estate vaults work?',
    'What is the optimal capital structure for my SME generating ₦350M ARR?',
    'Compare Sovereign Money Market Funds vs Senior Private Debt Notes.',
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full h-[600px] flex flex-col justify-between shadow-2xl overflow-hidden relative">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-blue-900/30">
              <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-bold text-white text-sm">EquiVest AI Portfolio Co-Pilot</h3>
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-blue-950 border border-blue-800 text-blue-400 font-bold">
                  Gemini 2.5
                </span>
              </div>
              <p className="text-[10px] text-slate-400">SEC-Compliant Institutional Financial Intelligence</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Messages Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-xs">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex gap-3 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'ai' && (
                <div className="w-7 h-7 rounded-lg bg-blue-950 border border-blue-700 flex items-center justify-center shrink-0 text-blue-400">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              <div
                className={`max-w-[80%] p-3.5 rounded-2xl space-y-1 ${
                  m.sender === 'user'
                    ? 'bg-blue-600 text-white font-medium rounded-tr-none shadow-md shadow-blue-900/20'
                    : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none leading-relaxed'
                }`}
              >
                <div className="whitespace-pre-line">{m.text}</div>
                <span className="block text-[9px] opacity-60 text-right">{m.time}</span>
              </div>
              {m.sender === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0 text-slate-300">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex justify-start gap-3 items-center text-slate-400 text-xs">
              <div className="w-7 h-7 rounded-lg bg-blue-950 border border-blue-700 flex items-center justify-center text-blue-400">
                <Bot className="w-4 h-4" />
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
                <span>Analyzing due diligence data...</span>
              </div>
            </div>
          )}
        </div>

        {/* Sample Prompt Chips */}
        <div className="p-2 bg-slate-950/60 border-t border-slate-800 flex overflow-x-auto gap-1.5 scrollbar-none">
          {sampleQuestions.map((q, i) => (
            <button
              key={i}
              onClick={() => setInputQuery(q)}
              className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[10px] text-slate-300 hover:text-white hover:border-emerald-500 whitespace-nowrap shrink-0 transition"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input Form */}
        <form onSubmit={handleSend} className="p-3 bg-slate-950 border-t border-slate-800 flex gap-2">
          <input
            type="text"
            placeholder="Ask AI about deals, fractional vaults, or capital strategy..."
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            className="flex-1 px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
          <button
            type="submit"
            disabled={loading || !inputQuery.trim()}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md disabled:opacity-50 transition flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
