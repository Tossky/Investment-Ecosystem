import React, { useState } from 'react';
import { Opportunity, Currency, AssetCategory } from '../types';
import { MOCK_OPPORTUNITIES } from '../data/mockData';
import { formatCurrency } from '../utils/formatters';
import {
  TrendingUp,
  ShieldCheck,
  Search,
  Filter,
  Users,
  Building,
  Lock,
  Calendar,
  DollarSign,
  FileText,
  ExternalLink,
  ChevronRight,
  CheckCircle2,
  AlertTriangle,
  Zap,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface MarketplaceProps {
  currency: Currency;
  onInvestInOpportunity: (opportunity: Opportunity, amountNgn: number) => void;
  onSwitchToSeeker: () => void;
}

export const Marketplace: React.FC<MarketplaceProps> = ({
  currency,
  onInvestInOpportunity,
  onSwitchToSeeker,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [minInvestmentFilter, setMinInvestmentFilter] = useState<number>(0);
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null);
  const [investAmountInput, setInvestAmountInput] = useState<number>(2000);
  const [investSuccessMessage, setInvestSuccessMessage] = useState<string | null>(null);

  const categories = ['All', 'Fractional Vault', 'Real Estate', 'Private Business Debt', 'Money Market', 'Tech Venture'];

  // Filter opportunities
  const filteredOpportunities = MOCK_OPPORTUNITIES.filter((opp) => {
    const matchesSearch =
      opp.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      opp.sponsorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      opp.category.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory = selectedCategory === 'All' || opp.category === selectedCategory;
    const matchesMin = minInvestmentFilter === 0 || opp.minInvestmentNgn <= minInvestmentFilter;

    return matchesSearch && matchesCategory && matchesMin;
  });

  const handleOpenDetail = (opp: Opportunity) => {
    setSelectedOpportunity(opp);
    setInvestAmountInput(opp.minInvestmentNgn);
    setInvestSuccessMessage(null);
  };

  const handleExecuteInvest = () => {
    if (!selectedOpportunity) return;
    if (investAmountInput < selectedOpportunity.minInvestmentNgn) {
      alert(`Minimum investment for this deal is ${formatCurrency(selectedOpportunity.minInvestmentNgn, currency)}`);
      return;
    }

    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
    });

    onInvestInOpportunity(selectedOpportunity, investAmountInput);
    setInvestSuccessMessage(`Successfully allocated ${formatCurrency(investAmountInput, currency)} to ${selectedOpportunity.title}! Units added to your Investor Portal.`);
    setTimeout(() => {
      setSelectedOpportunity(null);
      setInvestSuccessMessage(null);
    }, 2800);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Marketplace Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <TrendingUp className="w-3.5 h-3.5" /> Capital Marketplace & Asset Hub
          </div>
          <h1 className="text-2xl font-extrabold text-white mt-1">
            Vetted Investment Opportunities & Pooled Vaults
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Capital Providers browse SEC-vetted opportunities starting from ₦2,000 fractional micro-pools to institutional debt notes.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onSwitchToSeeker}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition flex items-center gap-2"
          >
            <Building className="w-4 h-4 text-white" />
            <span>Apply for Capital Raising</span>
          </button>
        </div>
      </div>

      {/* Search & Category Filter Bar */}
      <div className="flex flex-col lg:flex-row gap-4 justify-between items-stretch lg:items-center">
        {/* Category Pill Filters */}
        <div className="flex overflow-x-auto gap-2 pb-2 lg:pb-0 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-900/40'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {cat === 'Fractional Vault' ? '₦2,000 Micro-Vaults' : cat}
            </button>
          ))}
        </div>

        {/* Search input & Min Ticket Filter */}
        <div className="flex items-center gap-3">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by asset, sponsor, SEC reg..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          <select
            value={minInvestmentFilter}
            onChange={(e) => setMinInvestmentFilter(Number(e.target.value))}
            className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-blue-500 cursor-pointer"
          >
            <option value={0}>All Ticket Sizes</option>
            <option value={2000}>Min ₦2,000 (Micro)</option>
            <option value={50000}>Min ₦50,000</option>
            <option value={250000}>Min ₦250,000</option>
          </select>
        </div>
      </div>

      {/* Opportunity Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredOpportunities.map((opp) => {
          const fundingPcnt = Math.min(100, Math.round((opp.raisedCapitalNgn / opp.targetCapitalNgn) * 100));

          return (
            <div
              key={opp.id}
              className="group bg-slate-900 rounded-2xl border border-slate-800 hover:border-blue-500/50 transition-all duration-300 overflow-hidden flex flex-col justify-between shadow-xl hover:shadow-2xl hover:shadow-blue-950/20"
            >
              <div>
                {/* Image Banner & Badges */}
                <div className="relative h-48 overflow-hidden bg-slate-950">
                  <img
                    src={opp.image}
                    alt={opp.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

                  {/* Top Badges */}
                  <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
                    <span className="px-2.5 py-1 rounded-lg bg-slate-950/80 backdrop-blur-md border border-slate-700 text-[11px] font-extrabold text-blue-400">
                      {opp.category}
                    </span>
                    {opp.isFractionalPool && (
                      <span className="px-2.5 py-1 rounded-lg bg-blue-600/90 text-[11px] font-bold text-white shadow">
                        ₦2,000 Pooled Vault
                      </span>
                    )}
                  </div>

                  <div className="absolute top-3 right-3">
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-950/90 border border-emerald-500/50 text-emerald-300 font-extrabold text-xs">
                      {opp.expectedReturnPcnt}% p.a.
                    </span>
                  </div>

                  {/* Sponsor Name at bottom of image */}
                  <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-slate-300">
                    <span className="font-semibold text-slate-200 truncate">{opp.sponsorName}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-400 font-mono">
                      Rating: {opp.riskRating}
                    </span>
                  </div>
                </div>

                {/* Content Body */}
                <div className="p-5 space-y-4">
                  <div>
                    <h3 className="font-bold text-slate-100 text-base group-hover:text-blue-400 transition-colors line-clamp-1">
                      {opp.title}
                    </h3>
                    <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                      {opp.summary}
                    </p>
                  </div>

                  {/* Key Metrics Grid */}
                  <div className="grid grid-cols-2 gap-2 p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-xs">
                    <div>
                      <span className="text-slate-400 text-[10px] block font-medium">Minimum Ticket</span>
                      <span className="font-bold text-blue-400 font-mono">
                        {formatCurrency(opp.minInvestmentNgn, currency)}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] block font-medium">Tenure & Payout</span>
                      <span className="font-semibold text-slate-200">
                        {opp.tenureMonths} Mo ({opp.payoutFrequency})
                      </span>
                    </div>
                  </div>

                  {/* Funding Progress Bar */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-400 text-[11px]">
                        Raised: <strong className="text-slate-200">{formatCurrency(opp.raisedCapitalNgn, currency)}</strong>
                      </span>
                      <span className="font-extrabold text-emerald-400">{fundingPcnt}%</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-blue-500 to-emerald-400 h-full rounded-full transition-all duration-500"
                        style={{ width: `${fundingPcnt}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-[10px] text-slate-400">
                      <span>Target: {formatCurrency(opp.targetCapitalNgn, currency)}</span>
                      <span>{opp.coInvestorsCount} Co-Investors</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="p-5 pt-0">
                <button
                  onClick={() => handleOpenDetail(opp)}
                  className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-md shadow-blue-900/30"
                >
                  <span>Inspect Prospectus & Co-Invest</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Opportunity Detail & Investment Modal */}
      {selectedOpportunity && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-3xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative my-8">
            {/* Close Button */}
            <button
              onClick={() => setSelectedOpportunity(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-lg bg-slate-800/80 hover:bg-slate-800 transition text-xs font-bold"
            >
              ✕ Close
            </button>

            {/* Modal Title & Header */}
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-1 rounded-lg bg-emerald-950 border border-emerald-500/50 text-emerald-400 font-extrabold text-xs">
                  {selectedOpportunity.category}
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 font-mono text-xs">
                  SEC Reg: {selectedOpportunity.secRegNumber}
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-slate-800 text-amber-400 font-bold text-xs">
                  Due Diligence Score: {selectedOpportunity.dueDiligenceScore}/100
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white">{selectedOpportunity.title}</h2>
              <p className="text-xs sm:text-sm text-slate-400">{selectedOpportunity.subtitle}</p>
            </div>

            {/* Key Stats Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs">
              <div>
                <span className="text-slate-400 text-[10px] block">Annual Yield (ROI)</span>
                <span className="text-lg font-black text-emerald-400 font-mono">
                  {selectedOpportunity.expectedReturnPcnt}%
                </span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">Tenure</span>
                <span className="text-sm font-bold text-slate-200">{selectedOpportunity.tenureMonths} Months</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">Payout Frequency</span>
                <span className="text-sm font-bold text-slate-200">{selectedOpportunity.payoutFrequency}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">Min Ticket</span>
                <span className="text-sm font-bold text-emerald-400 font-mono">
                  {formatCurrency(selectedOpportunity.minInvestmentNgn, currency)}
                </span>
              </div>
            </div>

            {/* Highlights & Collateral */}
            <div className="space-y-4">
              <div>
                <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Key Investment Highlights
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {selectedOpportunity.highlights.map((hl, i) => (
                    <div key={i} className="flex items-start gap-2 p-2 bg-slate-950/60 rounded-lg border border-slate-800">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span className="text-slate-300">{hl}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Collateral & Custody Note */}
              <div className="p-3 bg-emerald-950/50 border border-emerald-900 rounded-xl text-xs space-y-1">
                <span className="font-bold text-emerald-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" /> Collateral & Escrow Security Statement
                </span>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  {selectedOpportunity.collateralDescription}
                </p>
              </div>
            </div>

            {/* Success Message Banner */}
            {investSuccessMessage && (
              <div className="p-4 bg-emerald-900/90 border border-emerald-500 rounded-xl text-xs text-white font-bold animate-fadeIn flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-300 shrink-0" />
                <span>{investSuccessMessage}</span>
              </div>
            )}

            {/* Investment Input & Execution Form */}
            {!investSuccessMessage && (
              <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                  <div>
                    <h4 className="text-sm font-bold text-white">Enter Co-Investment Amount</h4>
                    <p className="text-xs text-slate-400">
                      Available wallet balance: <strong className="text-slate-200">₦2,500,000</strong>
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setInvestAmountInput(selectedOpportunity.minInvestmentNgn)}
                      className="px-2.5 py-1 rounded bg-slate-800 text-xs text-slate-300 hover:text-white"
                    >
                      Min ({formatCurrency(selectedOpportunity.minInvestmentNgn, currency)})
                    </button>
                    <button
                      onClick={() => setInvestAmountInput(100000)}
                      className="px-2.5 py-1 rounded bg-slate-800 text-xs text-slate-300 hover:text-white"
                    >
                      ₦100k
                    </button>
                    <button
                      onClick={() => setInvestAmountInput(500000)}
                      className="px-2.5 py-1 rounded bg-slate-800 text-xs text-slate-300 hover:text-white"
                    >
                      ₦500k
                    </button>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="relative flex-1">
                    <span className="absolute left-3.5 top-3 text-slate-400 font-bold text-sm">₦</span>
                    <input
                      type="number"
                      min={selectedOpportunity.minInvestmentNgn}
                      value={investAmountInput}
                      onChange={(e) => setInvestAmountInput(Number(e.target.value))}
                      className="w-full pl-8 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-base font-bold text-white font-mono focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <button
                    onClick={handleExecuteInvest}
                    className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg transition flex items-center gap-2 shrink-0"
                  >
                    <Zap className="w-4 h-4 fill-amber-300 text-amber-300" />
                    <span>Confirm & Co-Fund</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
