import React, { useState } from 'react';
import { Currency } from '../types';
import { formatCurrency } from '../utils/formatters';
import {
  Briefcase,
  Calculator,
  ShieldCheck,
  TrendingUp,
  BarChart2,
  CheckCircle2,
  ArrowRight,
  FileText,
  Users,
  Award,
  Zap,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface GrowthServicesProps {
  currency: Currency;
  onBookConsultation: (topic: string) => void;
}

export const GrowthServices: React.FC<GrowthServicesProps> = ({
  currency,
  onBookConsultation,
}) => {
  // Valuation Calculator Inputs
  const [arrNgn, setArrNgn] = useState<number>(350000000); // ₦350M ARR
  const [growthRatePcnt, setGrowthRatePcnt] = useState<number>(45); // 45% YoY
  const [grossMarginPcnt, setGrossMarginPcnt] = useState<number>(55); // 55%
  const [targetCapitalNgn, setTargetCapitalNgn] = useState<number>(120000000); // ₦120M

  // Valuation Calculation Logic
  // Base multiple = 3.5x + growth bonus + margin bonus
  const multiple = 3.5 + (growthRatePcnt / 100) * 2.5 + (grossMarginPcnt / 100) * 1.5;
  const estimatedValuationNgn = Math.round(arrNgn * multiple);

  // Recommended Debt vs Equity Capital Mix
  const recommendedDebtPcnt = Math.min(65, Math.max(30, Math.round(grossMarginPcnt * 0.9)));
  const recommendedEquityPcnt = 100 - recommendedDebtPcnt;

  const debtAmountNgn = Math.round((targetCapitalNgn * recommendedDebtPcnt) / 100);
  const equityAmountNgn = Math.round((targetCapitalNgn * recommendedEquityPcnt) / 100);

  const services = [
    {
      id: 'cfo-service',
      title: 'Fractional CFO & Corporate Structuring',
      badge: 'B2B Growth Service',
      description: 'Institutional financial modeling, monthly board reporting, cashflow optimization, and Audit readiness by chartered accountants.',
      benefits: ['Audited Financial Statements (2-year history)', 'Debt-Service Coverage Ratio (DSCR) tuning', 'Tax Clearance Certificate (TCC) compliance'],
      priceNgn: 450000,
      period: '/month',
    },
    {
      id: 'sec-service',
      title: 'SEC SPV Trust & Regulatory Structuring',
      badge: 'Compliance & Legal',
      description: 'Complete legal setup of bankruptcy-remote Special Purpose Vehicles (SPV) with Meristem Trustees for debt issuing.',
      benefits: ['SEC Registration Filing & Issuance Code', 'First-Ranking Mortgage Charge Deed Drafting', 'Trustee & Escrow Custody Agreement'],
      priceNgn: 1200000,
      period: 'one-time setup',
    },
    {
      id: 'pitch-service',
      title: 'Investor Deck & Roadshow Package',
      badge: 'Investor Relations',
      description: 'Professional pitch deck design, financial model validation, and video pitch production tailored for retail & institutional syndicates.',
      benefits: ['15-slide institutional pitch deck', '3-minute executive video pitch', 'Direct feature in EquiVest Marketplace Header'],
      priceNgn: 350000,
      period: 'one-time',
    },
  ];

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <Briefcase className="w-3.5 h-3.5 text-blue-400" /> Business Growth Services & Structuring
          </div>
          <h1 className="text-2xl font-extrabold text-white mt-1">
            Business Growth & Capital Structuring Services
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Turn your business into an institutional-grade capital magnet with our Virtual CFO, SEC structuring, and interactive valuation engine.
          </p>
        </div>

        <button
          onClick={() => onBookConsultation('SME Capital Raising')}
          className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition flex items-center gap-2 shrink-0"
        >
          <Users className="w-4 h-4 text-white" />
          <span>Speak with Capital Advisor</span>
        </button>
      </div>

      {/* Interactive Valuation & Capital Mix Calculator */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex flex-wrap justify-between items-center gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-400 uppercase tracking-wider">
              <Calculator className="w-4 h-4" /> Interactive Calculator
            </div>
            <h2 className="text-xl font-extrabold text-white">SME Valuation & Capital Mix Simulator</h2>
          </div>
          <div className="text-right">
            <span className="text-xs text-slate-400">Implied Business Valuation</span>
            <p className="text-2xl font-black text-emerald-400 font-mono">
              {formatCurrency(estimatedValuationNgn, currency)}
            </p>
            <span className="text-[10px] text-slate-400">Based on {multiple.toFixed(2)}x ARR Multiple</span>
          </div>
        </div>

        {/* Sliders & Inputs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* ARR Slider */}
          <div className="space-y-2 bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-300">Annual Revenue (ARR)</span>
              <span className="font-bold text-emerald-400 font-mono">{formatCurrency(arrNgn, currency)}</span>
            </div>
            <input
              type="range"
              min="20000000"
              max="2000000000"
              step="10000000"
              value={arrNgn}
              onChange={(e) => setArrNgn(Number(e.target.value))}
              className="w-full accent-emerald-500 h-2 bg-slate-800 rounded"
            />
          </div>

          {/* Growth Rate */}
          <div className="space-y-2 bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-300">YoY Revenue Growth</span>
              <span className="font-bold text-emerald-400 font-mono">{growthRatePcnt}% YoY</span>
            </div>
            <input
              type="range"
              min="5"
              max="200"
              step="5"
              value={growthRatePcnt}
              onChange={(e) => setGrowthRatePcnt(Number(e.target.value))}
              className="w-full accent-emerald-500 h-2 bg-slate-800 rounded"
            />
          </div>

          {/* Gross Margin */}
          <div className="space-y-2 bg-slate-950 p-4 rounded-xl border border-slate-800">
            <div className="flex justify-between text-xs">
              <span className="font-semibold text-slate-300">Gross Profit Margin</span>
              <span className="font-bold text-emerald-400 font-mono">{grossMarginPcnt}%</span>
            </div>
            <input
              type="range"
              min="15"
              max="90"
              step="5"
              value={grossMarginPcnt}
              onChange={(e) => setGrossMarginPcnt(Number(e.target.value))}
              className="w-full accent-emerald-500 h-2 bg-slate-800 rounded"
            />
          </div>
        </div>

        {/* Recommended Capital Mix Output */}
        <div className="p-5 bg-emerald-950/40 border border-emerald-900 rounded-xl space-y-4">
          <h4 className="text-sm font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" /> Recommended Optimal Capital Structure
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800 space-y-1">
              <div className="flex justify-between items-center">
                <span className="font-bold text-emerald-400">Senior Commercial Debt ({recommendedDebtPcnt}%)</span>
                <span className="font-mono text-white font-bold">{formatCurrency(debtAmountNgn, currency)}</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Minimizes equity dilution. Monthly interest distributions covered by gross margin.
              </p>
            </div>

            <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800 space-y-1">
              <div className="flex justify-between items-center">
                <span className="font-bold text-blue-400">Equity / Convertible Note ({recommendedEquityPcnt}%)</span>
                <span className="font-mono text-white font-bold">{formatCurrency(equityAmountNgn, currency)}</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Issued to strategic co-investors seeking long-term upside at Series A milestone.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Services Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {services.map((svc) => (
          <div
            key={svc.id}
            className="bg-slate-900 rounded-2xl border border-slate-800 p-6 flex flex-col justify-between hover:border-emerald-500/50 transition-all duration-300 shadow-xl space-y-6"
          >
            <div className="space-y-4">
              <span className="px-2.5 py-1 rounded-lg bg-emerald-950 border border-emerald-800 text-emerald-400 font-extrabold text-[11px]">
                {svc.badge}
              </span>
              <div>
                <h3 className="text-lg font-bold text-white">{svc.title}</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">{svc.description}</p>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-800">
                {svc.benefits.map((b, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{b}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 space-y-3">
              <div className="flex justify-between items-baseline">
                <span className="text-xl font-black text-white font-mono">
                  {formatCurrency(svc.priceNgn, currency)}
                </span>
                <span className="text-xs text-slate-400">{svc.period}</span>
              </div>

              <button
                onClick={() => {
                  confetti({ particleCount: 60, spread: 60, origin: { y: 0.6 } });
                  onBookConsultation(svc.title);
                }}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white font-bold text-xs border border-slate-700 hover:border-emerald-500 transition flex items-center justify-center gap-2"
              >
                <span>Enroll Business Service</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
