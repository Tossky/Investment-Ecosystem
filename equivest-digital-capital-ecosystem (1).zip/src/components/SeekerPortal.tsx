import React, { useState } from 'react';
import { CapitalRaiseApplication, Currency } from '../types';
import { INITIAL_SEEKER_RAISES } from '../data/mockData';
import { formatCurrency } from '../utils/formatters';
import {
  Building2,
  TrendingUp,
  FileCheck,
  PlusCircle,
  ShieldCheck,
  CheckCircle2,
  Upload,
  BarChart3,
  DollarSign,
  AlertCircle,
  Clock,
  Briefcase,
  Layers,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface SeekerPortalProps {
  currency: Currency;
  onGoToValuationCalculator: () => void;
}

export const SeekerPortal: React.FC<SeekerPortalProps> = ({
  currency,
  onGoToValuationCalculator,
}) => {
  const [raises, setRaises] = useState<CapitalRaiseApplication[]>(INITIAL_SEEKER_RAISES);
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState(false);

  // Application Form State
  const [companyName, setCompanyName] = useState('');
  const [industry, setIndustry] = useState('Renewable Energy');
  const [fundingType, setFundingType] = useState<'Commercial Debt' | 'Equity Share' | 'Revenue Share' | 'Real Estate Syndication'>('Commercial Debt');
  const [targetAmountNgn, setTargetAmountNgn] = useState<number>(150000000);
  const [offeredYieldPcnt, setOfferedYieldPcnt] = useState<number>(21.0);
  const [tenureMonths, setTenureMonths] = useState<number>(12);
  const [useOfFunds, setUseOfFunds] = useState('');
  const [collateral, setCollateral] = useState('');

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyName || !useOfFunds) {
      alert('Please fill out all required fields.');
      return;
    }

    const newRaise: CapitalRaiseApplication = {
      id: `raise-${Date.now()}`,
      companyName,
      industry,
      fundingType,
      targetAmountNgn,
      offeredYieldPcnt,
      tenureMonths,
      useOfFunds,
      collateralProvided: collateral || 'Corporate Guarantee & Asset Pledge',
      arrNgn: 350000000,
      grossMarginPcnt: 38,
      status: 'Under Review',
      vettingScore: 91,
    };

    setRaises([newRaise, ...raises]);
    confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    setSubmissionSuccess(true);
    setTimeout(() => {
      setSubmissionSuccess(false);
      setShowApplyModal(false);
      setCompanyName('');
      setUseOfFunds('');
      setCollateral('');
    }, 2500);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Seeker Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <Building2 className="w-3.5 h-3.5" /> Capital Seekers & Corporate Debt Hub
          </div>
          <h1 className="text-2xl font-extrabold text-white mt-1">
            Raise Business Capital & Asset Funding
          </h1>
          <p className="text-slate-400 text-xs sm:text-sm mt-0.5">
            Submit your expansion plans, debt notes, or real estate projects to thousands of retail co-investors and institutional capital providers.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={onGoToValuationCalculator}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition flex items-center gap-2"
          >
            <BarChart3 className="w-4 h-4 text-blue-400" />
            <span>Valuation & Capital Calculator</span>
          </button>
          <button
            onClick={() => setShowApplyModal(true)}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md transition flex items-center gap-2"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Capital Application</span>
          </button>
        </div>
      </div>

      {/* Vetting Scorecard & Requirement Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400 block font-semibold">1. Credit & Debt Coverage</span>
          <p className="text-base font-bold text-slate-100">DSCR ≥ 1.35x Minimum</p>
          <p className="text-[11px] text-slate-400">Cashflow must comfortably cover coupon repayments</p>
        </div>
        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400 block font-semibold">2. Collateral Protection</span>
          <p className="text-base font-bold text-slate-100">120%+ Asset Pledge</p>
          <p className="text-[11px] text-slate-400">Equipment, receivables lien, or landed property C of O</p>
        </div>
        <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-1">
          <span className="text-xs text-slate-400 block font-semibold">3. Legal SPV Escrow</span>
          <p className="text-base font-bold text-slate-100">Bankruptcy Remote SPV</p>
          <p className="text-[11px] text-emerald-400 font-medium">Funds held safely in Providus Bank Escrow</p>
        </div>
      </div>

      {/* Applications & Live Raise Tracker */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-xl p-6 space-y-6">
        <div className="flex justify-between items-center pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-base font-bold text-white">Your Active Capital Applications</h3>
            <p className="text-xs text-slate-400">Track vetting progress, credit committee reviews, and investor pledges</p>
          </div>
          <span className="text-xs text-slate-400 font-mono">{raises.length} Applications</span>
        </div>

        <div className="space-y-4">
          {raises.map((raise) => (
            <div
              key={raise.id}
              className="p-5 bg-slate-950 rounded-xl border border-slate-800 hover:border-slate-700 transition space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold text-[10px]">
                      {raise.fundingType}
                    </span>
                    <span className="px-2.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px] font-mono">
                      Industry: {raise.industry}
                    </span>
                  </div>
                  <h4 className="text-lg font-bold text-white mt-1">{raise.companyName}</h4>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block">Vetting Score</span>
                    <span className="text-sm font-black text-emerald-400 font-mono">{raise.vettingScore}/100</span>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold border ${
                      raise.status === 'Live in Marketplace'
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                        : raise.status === 'Vetted & Approved'
                        ? 'bg-blue-950 text-blue-300 border-blue-800'
                        : 'bg-amber-950 text-amber-300 border-amber-800'
                    }`}
                  >
                    {raise.status}
                  </span>
                </div>
              </div>

              {/* Details grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-slate-900 rounded-lg border border-slate-800/80 text-xs">
                <div>
                  <span className="text-slate-400 text-[10px] block">Target Raising</span>
                  <span className="font-bold text-white font-mono">
                    {formatCurrency(raise.targetAmountNgn, currency)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Offered Coupon / ROI</span>
                  <span className="font-bold text-emerald-400 font-mono">{raise.offeredYieldPcnt}% p.a.</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Tenure</span>
                  <span className="font-semibold text-slate-200">{raise.tenureMonths} Months</span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Annual Revenue (ARR)</span>
                  <span className="font-semibold text-slate-200">{formatCurrency(raise.arrNgn, currency)}</span>
                </div>
              </div>

              {/* Use of Funds */}
              <p className="text-xs text-slate-300">
                <strong className="text-slate-400">Use of Funds:</strong> {raise.useOfFunds}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Apply Modal */}
      {showApplyModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative my-8">
            <button
              onClick={() => setShowApplyModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-2 rounded-lg bg-slate-800 hover:bg-slate-700 transition text-xs font-bold"
            >
              ✕ Close
            </button>

            <div>
              <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">
                Capital Raising Application
              </span>
              <h2 className="text-xl font-extrabold text-white mt-1">Submit Corporate Debt or Equity Offering</h2>
              <p className="text-xs text-slate-400">Our SEC-licensed credit committee reviews applications within 48 hours.</p>
            </div>

            {submissionSuccess ? (
              <div className="p-6 bg-emerald-950 border border-emerald-500 rounded-xl text-center space-y-3">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto animate-bounce" />
                <h3 className="text-lg font-bold text-white">Application Submitted Successfully!</h3>
                <p className="text-xs text-slate-300">
                  Your offering is now undergoing automated credit scoring and collateral verification. Track updates in your Seeker Dashboard.
                </p>
              </div>
            ) : (
              <form onSubmit={handleApplySubmit} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Company / Entity Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Apex Cold Chain Logistics Ltd"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Industry Sector</label>
                    <select
                      value={industry}
                      onChange={(e) => setIndustry(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-emerald-500"
                    >
                      <option value="Renewable Energy">Renewable Energy</option>
                      <option value="Healthcare & Supply Chain">Healthcare & Supply Chain</option>
                      <option value="Agriculture & Cold Chain">Agriculture & Cold Chain</option>
                      <option value="Commercial Real Estate">Commercial Real Estate</option>
                      <option value="B2B Fintech & SaaS">B2B Fintech & SaaS</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Funding Structure</label>
                    <select
                      value={fundingType}
                      onChange={(e) => setFundingType(e.target.value as any)}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-emerald-500"
                    >
                      <option value="Commercial Debt">Secured Commercial Debt</option>
                      <option value="Revenue Share">Revenue Share Pool</option>
                      <option value="Equity Share">Equity Syndication</option>
                      <option value="Real Estate Syndication">Real Estate SPV</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Target Capital (₦)</label>
                    <input
                      type="number"
                      value={targetAmountNgn}
                      onChange={(e) => setTargetAmountNgn(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 font-mono font-bold focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">Offered ROI (% p.a.)</label>
                    <input
                      type="number"
                      step="0.5"
                      value={offeredYieldPcnt}
                      onChange={(e) => setOfferedYieldPcnt(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 font-mono font-bold focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Use of Raised Capital *</label>
                  <textarea
                    rows={3}
                    required
                    placeholder="Describe asset acquisition, inventory procurement, or expansion timeline..."
                    value={useOfFunds}
                    onChange={(e) => setUseOfFunds(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Collateral Pledged & Security</label>
                  <input
                    type="text"
                    placeholder="e.g., Equipment Lien, Receivables Escrow Account, Governor's Consent C of O"
                    value={collateral}
                    onChange={(e) => setCollateral(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setShowApplyModal(false)}
                    className="px-4 py-2 bg-slate-800 text-slate-300 font-semibold rounded-xl hover:bg-slate-700"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-lg transition"
                  >
                    Submit Application for Credit Review
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
