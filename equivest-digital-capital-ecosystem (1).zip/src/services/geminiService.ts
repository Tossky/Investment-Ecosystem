export async function askBammyAiAssistant(userPrompt: string, contextData?: string): Promise<string> {
  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userPrompt, contextData }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.text) {
        return data.text;
      }
    }
  } catch (err) {
    console.warn('Backend AI route failed, using smart advisor fallback:', err);
  }

  // Fallback intelligent response generator based on key prompt terms
  const promptLower = userPrompt.toLowerCase();

  if (promptLower.includes('real estate') || promptLower.includes('property') || promptLower.includes('vault')) {
    return `**Bammy Growth Analysis: Real Estate & Pooled Asset Vaults**\n\n- **Principle Check:** First ensure your emergency reserve covers 3-6 months before locking capital.\n- **Risk-Adjusted Profile:** Class-A Commercial Real Estate & Pooled Vaults starting at ₦2,000 provide strong inflation hedging with typical cash yields between 16% - 22% p.a.\n- **Regulatory Protection:** Co-investing via legal SPV trust vaults (Meristem Trustees) ensures bankruptcy-remote custody.\n- **Recommended Route:** Route 01 (Investment Ready) or Route 02 (Cash Flow Builder).`;
  }

  if (promptLower.includes('sme') || promptLower.includes('business') || promptLower.includes('capital') || promptLower.includes('funding')) {
    return `**Bammy Business Funding & Due-Diligence Process**\n\n1. **Application & Analysis:** Submit your company profile, revenue, cash flows, and collateral.\n2. **Due Diligence Engine:** Our 8-point scoring evaluates Management (e.g. 78/100), Financial Health, Market Opportunity, and Capital Efficiency.\n3. **Human Investment Committee:** No AI approves capital independently. Our Investment Committee reviews due diligence before approving deals for marketplace listing or partner syndication.\n4. **Growth Support:** Funded businesses receive strategy, advisory, technology, and monitoring.`;
  }

  if (promptLower.includes('assessment') || promptLower.includes('readiness') || promptLower.includes('score')) {
    return `**Bammy Financial Readiness Assessment Framework**\n\n- **Multi-Vector Scoring:** Evaluates Financial Stability, Cash-Flow Strength, Investment Knowledge, Liquidity Position, Risk Capacity, and Goal Clarity.\n- **Pathway Guidance:** If your score indicates high readiness, you access vetted partner opportunities. If cash flow is tight, we route you to **Route 02: Build Cash Flow First** or **Route 03: Invest In Yourself**.`;
  }

  return `**Bammy Growth Intelligence Summary**\n\n- **Core Philosophy:** We don't push financial products. We assess where you are and recommend the smartest next step.\n- **5 Growth Pathways:** Whether you need Investment Readiness, Cash-Flow Building, Skill Education, Business Strategy, or 1-on-1 Consultation, we guide you step-by-step.\n- **Regulatory Firewall:** Licensed partner execution, SEC/CBN compliance, clear disclosures, and human Investment Committee governance.`;
}

// Keep export for backward compatibility
export const askEquiVestAiAssistant = askBammyAiAssistant;


