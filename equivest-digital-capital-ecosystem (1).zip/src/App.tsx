/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Currency, PortfolioAllocation, Opportunity, UserInvestment } from './types';
import { INITIAL_USER_INVESTMENTS } from './data/mockData';
import { Header } from './components/Header';
import { MatchmakingEngine } from './components/MatchmakingEngine';
import { Marketplace } from './components/Marketplace';
import { InvestorPortal } from './components/InvestorPortal';
import { SeekerPortal } from './components/SeekerPortal';
import { GrowthServices } from './components/GrowthServices';
import { ConsultationBooking } from './components/ConsultationBooking';
import { Academy } from './components/Academy';
import { ArchitectureBlueprint } from './components/ArchitectureBlueprint';
import { AiAssistantModal } from './components/AiAssistantModal';
import { Footer } from './components/Footer';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('matchmaker');
  const [currency, setCurrency] = useState<Currency>('NGN');
  const [userRole, setUserRole] = useState<'investor' | 'seeker' | 'advisor' | 'admin'>('investor');
  const [isAiModalOpen, setIsAiModalOpen] = useState<boolean>(false);
  const [userInvestments, setUserInvestments] = useState<UserInvestment[]>(INITIAL_USER_INVESTMENTS);
  const [consultationTopic, setConsultationTopic] = useState<string>('');

  // Handle Deploy Allocation from Matchmaker
  const handleDeployAllocation = (allocations: PortfolioAllocation[]) => {
    const newInvestments: UserInvestment[] = allocations
      .filter((a) => a.recommendedNgn > 0)
      .map((a, idx) => ({
        id: `inv-${Date.now()}-${idx}`,
        opportunityId: `opp-allocated-${idx}`,
        opportunityTitle: `${a.category} - Algorithmic Match Pool`,
        category: a.category,
        amountNgn: a.recommendedNgn,
        amountUsd: a.recommendedUsd,
        investedDate: new Date().toISOString().split('T')[0],
        maturityDate: '2027-08-01',
        expectedPayoutNgn: Math.round(a.recommendedNgn * (1 + a.expectedYieldPcnt / 100)),
        expectedPayoutUsd: Math.round(a.recommendedUsd * (1 + a.expectedYieldPcnt / 100)),
        yieldEarnedToDateNgn: 0,
        status: 'Active',
        nextPayoutDate: '2026-08-30',
      }));

    setUserInvestments((prev) => [...newInvestments, ...prev]);
    setActiveTab('investor-portal');
  };

  // Handle Direct Co-Invest in Marketplace
  const handleInvestInOpportunity = (opp: Opportunity, amountNgn: number) => {
    const newInv: UserInvestment = {
      id: `inv-mp-${Date.now()}`,
      opportunityId: opp.id,
      opportunityTitle: opp.title,
      category: opp.category,
      amountNgn: amountNgn,
      amountUsd: Math.round(amountNgn / 1550),
      investedDate: new Date().toISOString().split('T')[0],
      maturityDate: '2027-08-01',
      expectedPayoutNgn: Math.round(amountNgn * (1 + opp.expectedReturnPcnt / 100)),
      expectedPayoutUsd: Math.round((amountNgn / 1550) * (1 + opp.expectedReturnPcnt / 100)),
      yieldEarnedToDateNgn: 0,
      status: 'Active',
      nextPayoutDate: '2026-08-30',
    };

    setUserInvestments((prev) => [newInv, ...prev]);
  };

  const handleBookConsultationTopic = (topic: string) => {
    setConsultationTopic(topic);
    setActiveTab('consultation');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col justify-between selection:bg-emerald-500 selection:text-white w-full max-w-full overflow-x-hidden">
      {/* Global Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currency={currency}
        setCurrency={setCurrency}
        userRole={userRole}
        setUserRole={setUserRole}
        onOpenAiAssistant={() => setIsAiModalOpen(true)}
      />

      {/* Main View Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {activeTab === 'matchmaker' && (
          <MatchmakingEngine
            currency={currency}
            onDeployAllocation={handleDeployAllocation}
            onSelectMarketplaceItem={(id) => setActiveTab('marketplace')}
            onSwitchToSeeker={() => setActiveTab('seeker-portal')}
            onBookConsultation={handleBookConsultationTopic}
            onOpenAcademy={() => setActiveTab('academy')}
          />
        )}

        {activeTab === 'marketplace' && (
          <Marketplace
            currency={currency}
            onInvestInOpportunity={handleInvestInOpportunity}
            onSwitchToSeeker={() => setActiveTab('seeker-portal')}
          />
        )}

        {activeTab === 'investor-portal' && (
          <InvestorPortal
            currency={currency}
            userInvestments={userInvestments}
          />
        )}

        {activeTab === 'seeker-portal' && (
          <SeekerPortal
            currency={currency}
            onGoToValuationCalculator={() => setActiveTab('growth-services')}
          />
        )}

        {activeTab === 'growth-services' && (
          <GrowthServices
            currency={currency}
            onBookConsultation={handleBookConsultationTopic}
          />
        )}

        {activeTab === 'consultation' && (
          <ConsultationBooking
            currency={currency}
            preSelectedTopic={consultationTopic}
          />
        )}

        {activeTab === 'academy' && (
          <Academy currency={currency} />
        )}

        {activeTab === 'architecture' && (
          <ArchitectureBlueprint />
        )}
      </main>

      {/* AI Assistant Modal */}
      <AiAssistantModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
      />

      {/* Global Footer */}
      <Footer />
    </div>
  );
}
