import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

let aiInstance: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI | null {
  if (!aiInstance && process.env.GEMINI_API_KEY) {
    aiInstance = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return aiInstance;
}

// API Routes
app.post('/api/chat', async (req, res) => {
  try {
    const { userPrompt, contextData } = req.body;
    if (!userPrompt) {
      return res.status(400).json({ error: 'userPrompt is required' });
    }

    const client = getAiClient();
    if (!client) {
      return res.status(503).json({ error: 'GEMINI_API_KEY is not configured on server' });
    }

    const systemContext = `
You are Bammy Growth AI Co-Pilot, the intelligent financial growth advisor for Bammy Growth Hub.
Bammy Growth Hub is an AI-first Financial Growth, Investment Intelligence and Business Opportunity Ecosystem.
Our Central Philosophy: "Not everyone who has money needs an investment immediately. Sometimes the best investment is first creating the ability to generate more money."

Your goal is to guide users through:
Assessment -> Understanding -> Strategy -> Opportunity -> Capital -> Growth -> Monitoring -> Wealth Creation.

The platform has 5 primary routes based on Investment Readiness Scores:
1. Route 01: Investment Ready (Sufficient stability -> Vetted regulated opportunities)
2. Route 02: Build Cash Flow First (Income Growth -> Savings Discipline -> Foundation)
3. Route 03: Invest In Yourself (Education, Certifications, Career & Skill Growth)
4. Route 04: Business Growth (Strategy, Marketing, Tech, Capital Readiness)
5. Route 05: Personal Consultation (1-on-1 expert human advisory)

Always be concise, structured, professional, empathetic, and compliant with SEC & CBN regulatory guidelines (clearly separating advisory from execution and noting that AI provides decision support, not guaranteed financial promises).
`;

    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `${systemContext}\n\nAdditional Context:\n${contextData || ''}\n\nUser Question:\n${userPrompt}`,
    });

    return res.json({ text: response.text || '' });
  } catch (error: any) {
    console.error('Server Gemini Error:', error);
    return res.status(500).json({ error: error?.message || 'Failed to generate response' });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
